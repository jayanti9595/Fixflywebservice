const connection = require("../connection/dbConfig");

const getUserDetails = (user_id) => {
    return new Promise((resolve, reject) => {
        const sqlSelect = "SELECT * FROM user_master WHERE user_id = ? AND delete_flag = 0";
        connection.query(sqlSelect, [user_id], (error, result) => {
            if(error) {
                reject(error.message);
            }
            if(result.length > 0) {
                return resolve(result[0]);
            }
        })
    })
}

function fetchUserData(userId, callback) {
    const query = "SELECT * FROM user_master WHERE  user_id = ? AND delete_flag =0";
    connection.query(query, [userId], async (error, results) => {
      if (error) {
        callback(error, null);
        return;
      }
      if (results.length > 0) {
        const userData = results[0];
        const userDataArray = {
          user_id: userData.user_id,
          login_type: userData.login_type,
          login_type_label: "0=app, 1=google, 2=apple",
          user_type: userData.user_type,
          user_type_label: "0 for admin, 1 for user, 2 for vendor",
          email: userData.email,
          name: userData.name,
          apple_id: userData.apple_id,
          google_id: userData.google_id,
          pincode: userData.pincode,
          street : userData.street,
          city: userData.city,
          country_id: userData.country_id,
          mobile: userData.mobile,
          phone_code: userData.phone_code,
          otp: userData.otp,
          otp_verify: userData.otp_verify,
          image: userData.image,
          address: userData.address,
          latitude: userData.latitude,
          longitude: userData.longitude,
          createtime: userData.createtime,
          updatetime: userData.updatetime,
        };
        callback(null, userDataArray);
      } else {
        callback(null, null);
      }
    });
  }

  
  module.exports = {fetchUserData}