var message = {
    empt_params : ["Please Send Data"],
    internalServerError : ["Internal Server Error"],
    msgDataFound : ["Data Found Successfully"],
    userNotFound : ["User Not Found"],
    userAccountDeactivate : ["User Account Deactivated by Admin"],
    dataUpdated : ["profile  Created Successfully"],
    ticketAdded : ["Ticket Added Successfully"],
    planPurchased : ["Plan Purchases Successfully"],
    bookingNotFound : ["Booking Not Found"],
    bookingCancelled : ["Booking cancelled successfully"],
    bookingRescheduled : ["Booking rescheduled successfully"],
    serviceBookedSuccess : ["Service Booked Successfully"]
}

module.exports = message;