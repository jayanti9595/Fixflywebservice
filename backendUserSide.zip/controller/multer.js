var multer = require("multer");
var storage = multer.diskStorage({
    destination : "./images",
    filename : (req, file, cb) =>{
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + uniqueSuffix)
    }
});

var upload = multer({storage : storage});
module.exports = upload;