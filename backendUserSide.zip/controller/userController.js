const connection = require("../connection/dbConfig");
const { fetchUserData } = require("./function");
const message = require("./language")
const axios = require('axios');
const moment = require("moment");

const signIn = async (request, response) => {
    const { mobile } = request.body;
    try {
        if (!mobile) {
            return response.status(200).json({ success: false, msg: message.empt_params, key: "mobile" });
        }
        const otp = 123456;
        // Check if mobile exists
        const checkSql = "SELECT otp_verify FROM user_master WHERE mobile = ?";
        connection.query(checkSql, [mobile], (checkErr, checkResult) => {
            if (checkErr) {
                return response.status(200).json({ success: false, msg: message.internalServerError, err: checkErr.message });
            }
            if (checkResult && checkResult.length > 0) {
                if (checkResult[0].otp_verify === 1) {
                    return response.status(200).json({ success: false, msg: "Mobile number already exists.", key: "mobile" });
                } else {
                    const updateSql = "UPDATE user_master SET otp = ?, updatetime = NOW() WHERE mobile = ?";
                    connection.query(updateSql, [otp, mobile], (updateErr, updateResult) => {
                        if (updateErr) {
                            return response.status(200).json({ success: false, msg: message.internalServerError, err: updateErr.message });
                        }
                        return response.status(200).json({ success: true, msg: "OTP sent successfully to existing user." });
                    });
                }
            } else {
                const insertSql = "INSERT INTO user_master(mobile, otp, updatetime, createtime) VALUES (?, ?, NOW(), NOW())";
                connection.query(insertSql, [mobile, otp], (error, insertResult) => {
                    if (error) {
                        return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
                    }
                    return response.status(200).json({ success: true, msg: "OTP sent successfully to new user." });
                });
            }
        });
    } catch (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
    }
};

const getBanner = async (request, response) => {
    try {
      var sqlSelect = "SELECT banner_id, image, DATE_FORMAT(createtime, '%d-%m-%Y %h:%i %p') as createtime_format  FROM banner_master WHERE delete_flag = 0 order by banner_id desc";
      connection.query(sqlSelect, async (error, result) => {
        if (error) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, banner_arr: result.length > 0 ? result : "NA" });
      })
    } catch (error) {
      return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
    }
  }
const getFaq = (request, response) => {
    try {
        var sqlSelect = "SELECT faq_id,question,answer FROM faq_master WHERE delete_flag = 0";
        connection.query(sqlSelect,(error,result) => {
            if(error) {
                return response.status(200).json({success : false, msg : message.internalServerError, err : err.message})  
            }
            var faq_arr = [];
            if(result.length > 0) {
                for(var data of result) {
                    faq_arr.push({
                        faq_id : data.faq_id,
                        question : data.question,
                        answer : data.answer,
                        status : false
                    });
                }
                return response.status(200).json({success : true, msg : message.msgDataFound, faq_arr : faq_arr.length > 0 ? faq_arr : "NA"})  
            } else {
                return response.status(200).json({success : true, msg : message.msgDataFound, faq_arr : "NA"})  
            }
        })   
    } catch (error) {
      return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
    }
}

const getCategory = (request, response) => {
    try {
        var sqlSelect = "SELECT category_id,name,image FROM category_master WHERE delete_flag = 0";
        connection.query(sqlSelect,(error,result) => {
            if(error) {
                return response.status(200).json({success : false, msg : message.internalServerError, err : err.message})  
            }
            var category_arr = [];
            if(result.length > 0) {
                for(var data of result) {
                    category_arr.push({
                        category_id : data.category_id,
                        name : data.name,
                        image : data.image,
                        status : false
                    });
                }
                return response.status(200).json({success : true, msg : message.msgDataFound, category_arr : category_arr.length > 0 ? category_arr : "NA"})  
            } else {
                return response.status(200).json({success : true, msg : message.msgDataFound, category_arr : "NA"})  
            }
        })   
    } catch (error) {
      return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
    }
}

const getSubCategory = (request, response) => {
    const {category_id} = request.query;
    if(!category_id) {
        return response.status(200).json({success : false, msg : message.empt_params,key : "category_id"})
    }
    try {
        var sqlSelect = "SELECT sub_category_id,category_id,name,image FROM sub_category_master WHERE delete_flag = 0 AND category_id = ?";
        connection.query(sqlSelect,[category_id],(error,result) => {
            if(error) {
                return response.status(200).json({success : false, msg : message.internalServerError, err : err.message})  
            }
             var sub_category_arr = [];
            if(result.length > 0) {
                for(var data of result) {
                    sub_category_arr.push({
                        sub_category_id : data.sub_category_id,
                        category_id : data.category_id,
                        name : data.name,
                        image : data.image,
                        status : false
                    });
                }
                return response.status(200).json({success : true, msg : message.msgDataFound, sub_category_arr : sub_category_arr.length > 0 ? sub_category_arr : "NA"})  
            } else {
                return response.status(200).json({success : true, msg : message.msgDataFound, sub_category_arr : "NA"})  
            }
        })   
    } catch (error) {
      return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
    }
}

const createUserProfile = (request, response) => {
    const {name,mobile,city,pincode,street, user_id, email} = request.body;
    try {
        if(!name) {
            return response.status(200).json({success : false, msg : message.empt_params,key : "name"})
        }
        if(!email) {
            return response.status(200).json({success : false, msg : message.empt_params,key : "email"})
        }
        if(!user_id) {
            return response.status(200).json({success : false, msg : message.empt_params,key : "user_id"})
        }
        if(!mobile) {
            return response.status(200).json({success : false, msg : message.empt_params,key : "mobile"})
        }
        if(!city) {
            return response.status(200).json({success : false, msg : message.empt_params,key : "city"})
        }
        if(!street) {
            return response.status(200).json({success : false, msg : message.empt_params,key : "street"})
        }
        if(!pincode) {
            return response.status(200).json({success : false, msg : message.empt_params,key : "pincode"})
        } 
        var sqlSelect = "SELECT active_flag FROM user_master WHERE user_id = ? AND delete_flag = 0";
        connection.query(sqlSelect,[user_id],(error,resultUser) => {
            if(error) {
                return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
            }
            if(resultUser.length > 0) {
                var updateUserData = "UPDATE user_master SET email = ?, profile_complete = ?, mobile = ?, user_type = ?,  name = ?, city= ?,pincode = ?, street = ?,updatetime = NOW() WHERE user_id = ? AND delete_flag = 0";
                connection.query(updateUserData,[email,1,mobile,1,name,city,pincode,street,user_id],(error,updateResult) => {
                    if(error) {
                        return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
                    }
                    fetchUserData(user_id,async (error, userDataArray) => {
                        if (error) {
                           return response.status(200).json({success: false,msg: message.internalServerError,error: error.message});
                        }                         
                        return response.status(200).json({success : true, msg : message.dataUpdated,userDataArray})  
                    });
                })
            } else {
                return response.status(200).json({success :false,msg : message.userNotFound})
            }
            // } else {
            //     var updateUserData = "INSERT INTO user_master(mobile,name,user_type,city,pincode, street,updatetime,createtime) VALUES (?,?,?,?,?,?,NOW(),NOW())";
            //     connection.query(updateUserData,[mobile,name,1,city,pincode,street],(error,insertResult) => {
            //         if(error) {
            //             return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
            //         }
            //         return response.status(200).json({success : true, msg : message.dataUpdated})  
            //     })
            // }
        });
    } catch (error) {
        return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
    }
}

const createTicket = (request, response) => {
    const {user_id,title,issue_desc} = request.body;
    try {
        if(!user_id) {
            return response.status(200).json({success : true,msg: message.empt_params,key : "user_id"})
        }
        if(!title) {
            return response.status(200).json({success : true,msg: message.empt_params,key : "title"})
        }
        if(!issue_desc) {
            return response.status(200).json({success : true,msg: message.empt_params,key : "issue_desc"})
        }
        var userSelect = "SELECT user_id,email,mobile FROM user_master WHERE user_id = ? AND delete_flag = 0";
        connection.query(userSelect,[user_id],(error, userResult) => {
            if(error) {
                return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
            }
            if(userResult.length <= 0) {
                return response.status(200).json({success :false,msg : message.userNotFound})
            }
            if(userResult[0].active_flag  == 1) {
                return response.status(200).json({success :false,msg : message.userAccountDeactivate})
            } 
            var mobile = userResult[0].mobile;
            var email = userResult[0].email;
            if(userResult.length > 0) {
                var sqlSelect = "INSERT INTO ticket_master(user_id,title,issue,email,mobile,createtime,updatetime) VALUES (?,?,?,?,?,NOW(),NOW())";
                connection.query(sqlSelect,[user_id,title,issue_desc,email,mobile],(error,result) => {
                    if(error) {
                        return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
                    }
                    return response.status(200).json({success : true,meg : message.ticketAdded})
                });
            }
        });
    } catch (error) {
        return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
    }
}

const getSubscription = (request, response) => {
    const {user_id} = request.query;
   try {
    if(!user_id) {
        return response.status(200).json({success : false,msg : message.empt_params,key : "user_id"})
    }
    var sqlSelect = "SELECT user_id FROM user_master WHERE delete_flag = 0 AND user_id = ?";
    connection.query(sqlSelect,[user_id],async (error,userResult) => {
        if(error) {
            return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
        }
        if(userResult.length <= 0) {
            return response.status(200).json({success :false,msg : message.userNotFound})
        }
        if(userResult[0].active_flag  == 1) {
            return response.status(200).json({success :false,msg : message.userAccountDeactivate})
        } 
        // var subscription_arr = []; 
        // if(userResult.length > 0) {
        //     var sqlSelect = "SELECT subscription_id,no_of_day,plan_name,plan_description FROM subscription_master WHERE delete_flag = 0";
        //     connection.query(sqlSelect,async (error,subscriptionResult) => {
        //         if(error) {
        //             return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
        //         }
        //         if(subscriptionResult.length > 0) {
        //             for(var data of subscriptionResult) {
        //                 subscription_arr.push({
        //                     subscription_id : data.subscription_id,
        //                     no_of_day : data.no_of_day,
        //                     plan_name : data.plan_name,
        //                     plan_decription : data.plan_decription,
        //                 })
        //             }
        //             return response.status(200).json({success :true,msg : message.msgDataFound,subscription_arr : subscription_arr.length > 0 ? subscription_arr : "NA"})
        //         } else {
        //            return response.status(200).json({success :true,msg : message.msgDataFound,subscription_arr :  "NA"})
        //         }
        //     })
        // }
        try {
            var sqlSelect = "SELECT subscription_id, no_of_day, plan_name, plan_description, createtime, updatetime, amount FROM subscription_master WHERE delete_flag = 0 ORDER BY subscription_id DESC";
            connection.query(sqlSelect, async (error, result) => {
              if (error) {
                return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
              }
              var amc_arr = [];
              if (result.length > 0) {
                for (var data of result) {
                  amc_arr.push({
                    subscription_id: data.subscription_id,
                    month: data.no_of_day,
                    plan_name: data.plan_name,
                    plan_description: data.plan_description,
                    amount: data.amount || 0.0,
                    createtime: data.createtime ? moment(data.createtime).format("DD-MM-YYYY HH:mm A") : "NA",
                    updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
                  });
                }
                return response.status(200).json({ success: true, msg: message.msgDataFound, amc_arr: amc_arr.length > 0 ? amc_arr : "NA" });
              } else {
                return response.status(200).json({ success: true, msg: message.msgDataFound, amc_arr: "NA" });
              }
            });
          } catch (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
          }
    })
   } catch (error) {
        return response.status(200).json({success : false, msg : message.internalServerError, err : error.message})  
   } 
}

const purchasePlan = async (request, response) => {
    const { user_id, no_of_day, subscription_id, plan_name, plan_description,transation_id } = request.body;
    try {
        if (!user_id) {
            return response.status(200).json({ success: false, msg: message.empt_params, key: "user_id" });
        }
        if (!no_of_day) {
            return response.status(200).json({ success: false, msg: message.empt_params, key: "no_of_day" });
        }
        if (!subscription_id) {
            return response.status(200).json({ success: false, msg: message.empt_params, key: "subscription_id" });
        }
        if (!plan_name) {
            return response.status(200).json({ success: false, msg: message.empt_params, key: "plan_name" });
        }
        if (!plan_description) {
            return response.status(200).json({ success: false, msg: message.empt_params, key: "plan_description" });
        }
        if (!transation_id) {
            return response.status(200).json({ success: false, msg: message.empt_params, key: "transation_id" });
        }
        const sqlSelect = "SELECT user_id, active_flag FROM user_master WHERE user_id = ? AND delete_flag = 0";
        connection.query(sqlSelect, [user_id], (error, userResult) => {
            if (error) {
                return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
            }
            if (!userResult || userResult.length === 0) {
                return response.status(200).json({ success: false, msg: message.userNotFound });
            }
            if (userResult[0].active_flag === 1) {
                return response.status(200).json({ success: false, msg: message.userAccountDeactivate });
            }
            const start_date = new Date();
            const end_date = new Date(start_date);
            end_date.setDate(end_date.getDate() + parseInt(no_of_day));
            const insertSQL = `INSERT INTO user_plan_master (user_id, no_of_day, start_date, end_date, subscription_id, plan_name, plan_description,transation_id,createtime,updatetime) VALUES (?, ?, ?, ?, ?, ?, ?, ?,NOW(),NOW())`;
            connection.query(insertSQL, [user_id,no_of_day,start_date,end_date,subscription_id,plan_name,plan_description,transation_id], (error, resultInsert) => {
                if (error) {
                    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
                }
                return response.status(200).json({ success: true, msg: message.planPurchased });
            });
        });

    } catch (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
    }
};

const getProduct = async (request, response) => {
    try {
      var sqlSelect = "SELECT product_id,sub_category_id,category_id, name, image, price, createtime FROM product_master WHERE delete_flag = 0 order by product_id desc";
      connection.query(sqlSelect, async (err, result) => {
        if (err) {
          return response.status(200).json({ success: false, msg: message.internalServerError });
        }
        var product_arr = [];
        if (result.length === 0) {
          return response.status(200).json({ success: true, msg: message.msgDataFound, product_arr: [] });
        }
        if (result.length > 0) {
          for (var data of result) {
            product_arr.push({
              product_id: data.product_id,
              name: data.name,
              image: data.image,
              price: data.price,
              category_id: data.category_id,
              sub_category_id: data.sub_category_id,
              category_name: await getCategoryName(data.category_id),
              sub_category_name: await getSubCategoryName(data.sub_category_id),
              createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
            })
          }
          return response.status(200).json({ success: true, msg: message.msgDataFound, product_arr: product_arr.length > 0 ? product_arr : "NA" });
        } else {
          return response.status(200).json({ success: true, msg: message.msgDataFound, product_arr: "NA" });
        }
      });
    } catch (error) {
      return response.status(200).json({ success: false, msg: message.internalServerError });
    }
  }


  async function getCategoryName(category_id) {
    return new Promise((resolve, reject) => {
      const sqlSelect = "SELECT name FROM category_master WHERE category_id = ? AND delete_flag = 0";
  
      connection.query(sqlSelect, [category_id], (error, results) => {
        if (error) {
          return reject(error);
        }
  
        if (results.length > 0) {
          resolve(results[0].name);
        } else {
          resolve("NA");
        }
      });
    });
  }
  
  async function getSubCategoryName(sub_category_id) {
    return new Promise((resolve, reject) => {
      const sqlSelect = "SELECT name FROM sub_category_master WHERE sub_category_id = ? AND delete_flag = 0";
  
      connection.query(sqlSelect, [sub_category_id], (error, results) => {
        if (error) {
          return reject(error);
        }
  
        if (results.length > 0) {
          resolve(results[0].name);
        } else {
          resolve("NA");
        }
      });
    });
  }

  const getProductDetail = async (request, response) => {
    const { product_id } = request.query;
  
    try {
      if (!product_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'product_id' });
      }
  
      var sqlSelect = "SELECT product_id,description, sub_category_id, category_id, name, image, price, createtime, updatetime FROM product_master WHERE product_id = ? AND delete_flag = 0 ORDER BY product_id DESC";
      connection.query(sqlSelect, [product_id], async (err, result) => {
        if (err) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: err.message });
        }
  
        if (result.length === 0) {
          return response.status(200).json({ success: true, msg: message.msgDataFound, productDetail : "NA" });
        }
  
        const data = result[0];
        const productDetail = {
          product_id: data.product_id,
          name: data.name,
          image: data.image,
          price: data.price,
          description: data.description || "NA",
          // status: data.status,
          category_id: data.category_id,
          sub_category_id: data.sub_category_id,
          category_name: await getCategoryName(data.category_id),
          sub_category_name: await getSubCategoryName(data.sub_category_id),
          ratings  : await getProductRatings(data.product_id),
          related_product : await getRelatedProduct(data.category_id, data.sub_category_id,data.product_id),
          createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
          updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
        };
  
        return response.status(200).json({
          success: true,
          msg: message.msgDataFound,
          product_detail: (productDetail) ? productDetail : "NA"
        });
      });
    } catch (error) {
      return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
    }
  }

  const getProductRatings = async (product_id) => {
    return new Promise((resolve,reject) => {
        const sqlSelect = "SELECT prrm.product_rating_review_id, prrm.rating,prrm.review,um.image,um.name,um.user_id from product_rating_review_master as prrm JOIN user_master as um ON prrm.user_id = um.user_id WHERE prrm.product_id = ? AND prrm.delete_flag = 0 AND um.delete_flag = 0 Order By prrm.product_rating_review_id DESC";
        var rating_arr = [];
        connection.query(sqlSelect, [product_id], (error, result) => {
            if(error) {
                reject(error.message);
            }
            if(result.length <= 0) {
                return resolve("NA")
            } else {
                for(var data of result) {
                    rating_arr.push({
                        rating_id : data.product_rating_review_id,
                        rating : data.rating,
                        rating_label : "1 for 1 star, 2 for 2 star, 3 for 3 star, 4 for 4 star, 5 for 5 star",
                        review : data.review,
                        name : data.name,
                        image : data.image,
                    });
                    resolve(rating_arr.length > 0 ? rating_arr : "NA")
                }
            }
        })
    })
  }

// Implementation of getRelatedProduct
const getRelatedProduct = async (category_id, sub_category_id, product_id) => {
    return new Promise((resolve, reject) => {
        const sqlSelect = "SELECT product_id, name, image, price FROM product_master WHERE category_id = ? AND sub_category_id = ? AND product_id != ? AND delete_flag = 0 LIMIT 5";
        connection.query(sqlSelect, [category_id, sub_category_id,product_id], (error, result) => {
            if (error) {
                return resolve("NA");
            }
            if (!result || result.length === 0) {
                return resolve("NA");
            }
            const relatedProducts = result.map(data => ({
                product_id: data.product_id,
                name: data.name,
                image: data.image,
                price: data.price
            }));
            resolve(relatedProducts);
        });
    });
};
const getProductsByCategorySubcategory = (request, response) => {
    var { category_id, sub_category_id } = request.query;
    if (!category_id || !sub_category_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'category_id or sub_category_id' });
    }
    const sqlSelect = "SELECT product_id, name, image, price, description FROM product_master WHERE category_id = ? AND sub_category_id = ? AND delete_flag = 0 ORDER BY product_id DESC";
    connection.query(sqlSelect, [category_id, sub_category_id],async (error, result) => {
        if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        if (!result || result.length === 0) {
            return response.status(200).json({ success: true, msg: message.msgDataFound, product_arr: "NA" });
        }
        const category_name = await getCategoryName(category_id);
        const sub_category_name = await getSubCategoryName(sub_category_id);
        const product_arr = result.map(data => ({
            product_id: data.product_id,
            name: data.name,
            image: data.image,
            price: data.price,
            description: data.description || "NA"
        }));
        return response.status(200).json({ success: true, msg: message.msgDataFound, product_arr,category_name,sub_category_name,total_product : result.length });
    });
};

const getTicket = (request, response) => {
    const { user_id } = request.query;
    if (!user_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'user_id' });
    }
    const sqlSelect = "SELECT ticket_id, title, issue, email, mobile,status,reply, createtime, updatetime FROM ticket_master WHERE user_id = ? AND delete_flag = 0 AND status = 0 ORDER BY ticket_id DESC";
    connection.query(sqlSelect, [user_id], (error, result) => {
        if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        if (!result || result.length === 0) {
            return response.status(200).json({ success: true, msg: message.msgDataFound, ticket_arr: "NA" });
        }
        const ticket_arr = result.map(data => ({
            ticket_id: data.ticket_id,
            title: data.title,
            issue: data.issue,
            email: data.email,
            mobile: data.mobile,
            status : data.status,
            status_label :"0 for pending, 1 for closed",
            reply : data.reply,
            resolved_date : moment(data.reply_datetime).format("DD-MM-YYYY HH:mm A"),
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
            updatetime: moment(data.updatetime).format("DD-MM-YYYY HH:mm A")
        }));
        return response.status(200).json({ success: true, msg: message.msgDataFound, ticket_arr });
    });
};

const getClosedTicket = (request, response) => {
    const { user_id } = request.query;
    if (!user_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'user_id' });
    }
    const sqlSelect = "SELECT ticket_id, title, issue, email, mobile,status,reply, createtime, updatetime FROM ticket_master WHERE user_id = ? AND delete_flag = 0 AND status = 1 ORDER BY ticket_id DESC";
    connection.query(sqlSelect, [user_id], (error, result) => {
        if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        if (!result || result.length === 0) {
            return response.status(200).json({ success: true, msg: message.msgDataFound, ticket_arr: "NA" });
        }
        const ticket_arr = result.map(data => ({
            ticket_id: data.ticket_id,
            title: data.title,
            issue: data.issue,
            email: data.email,
            mobile: data.mobile,
            status : data.status,
            status_label :"0 for pending, 1 for closed",
            reply : data.reply,
            resolved_date : moment(data.reply_datetime).format("DD-MM-YYYY HH:mm A"),
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
            updatetime: moment(data.updatetime).format("DD-MM-YYYY HH:mm A")
        }));
        return response.status(200).json({ success: true, msg: message.msgDataFound, ticket_arr });
    });
};

const addProductRatingReview = (request, response) => {
    const { product_id, user_id, rating, review } = request.body;
    if (!product_id || !user_id || !rating) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'product_id, user_id, or rating' });
    }
    // Check if a review already exists for this user and product
    const checkSql = "SELECT product_rating_review_id FROM product_rating_review_master WHERE product_id = ? AND user_id = ? AND delete_flag = 0";
    connection.query(checkSql, [product_id, user_id], (checkErr, checkResult) => {
        if (checkErr) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: checkErr.message });
        }
        if (checkResult && checkResult.length > 0) {
            // Update existing review
            const updateSql = "UPDATE product_rating_review_master SET rating = ?, review = ?, updatetime = NOW() WHERE product_id = ? AND user_id = ? AND delete_flag = 0";
            connection.query(updateSql, [rating, review || '', product_id, user_id], (updateErr, updateResult) => {
                if (updateErr) {
                    return response.status(200).json({ success: false, msg: message.internalServerError, error: updateErr.message });
                }
                return response.status(200).json({ success: true, msg: ['Rating and review Added successfully.'] });
            });
        } else {
            // Insert new review
            const sqlInsert = "INSERT INTO product_rating_review_master (product_id, user_id, rating, review, createtime, updatetime, delete_flag) VALUES (?, ?, ?, ?, NOW(), NOW(), 0)";
            connection.query(sqlInsert, [product_id, user_id, rating, review || ''], (error, result) => {
                if (error) {
                    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
                }
                return response.status(200).json({ success: true, msg: ['Rating and review added successfully.'] });
            });
        }
    });
};

const getUserPlan = (request, response) => {
    const { user_id } = request.query;
    if (!user_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'user_id' });
    }
    const sqlSelect = `SELECT user_plan_id,plan_name, plan_description, no_of_day, start_date, end_date, subscription_id, transation_id, createtime, updatetime FROM user_plan_master WHERE user_id = ? ORDER BY user_plan_id DESC`;
    connection.query(sqlSelect, [user_id], (error, result) => {
        if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        if (!result || result.length === 0) {
            return response.status(200).json({ success: true, msg: message.msgDataFound, plan_arr: "NA" });
        }
        const today = moment().startOf('day');
        const plan_arr = result.map(data => {
            const endDate = moment(data.end_date).startOf('day');
            const total = data.no_of_day;
            let remaining = endDate.diff(today, 'days');
            if (remaining < 0) remaining = 0;
            return {
                user_plan_id : data.user_plan_id,
                plan_name: data.plan_name,
                plan_description: data.plan_description,
                no_of_day: data.no_of_day,
                start_date: moment(data.start_date).format("DD MMM, YYYY"),
                end_date: moment(data.end_date).format("DD MMM, YYYY"),
                subscription_id: data.subscription_id,
                transation_id: data.transation_id,
                purchase_year : moment(data.start_date).format("YYYY"),
                createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
                updatetime: moment(data.updatetime).format("DD-MM-YYYY HH:mm A"),
                remaining_day: `${remaining}/${total}`
            }
        });
        return response.status(200).json({ success: true, msg: message.msgDataFound, plan_arr });
    });
};

const getBooking = (request, response) => {
    const { user_id } = request.query;
    if (!user_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'user_id' });
    }
    const sqlSelect = `SELECT case_id,booking_id, service_name, booking_date, status, amount, createtime, updatetime FROM booking_master WHERE user_id = ? ORDER BY booking_id DESC`;
    connection.query(sqlSelect, [user_id], (error, result) => {
        if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        if (!result || result.length === 0) {
            return response.status(200).json({ success: true, msg: message.msgDataFound, booking_arr: "NA" });
        }
        const booking_arr = result.map(data => ({
            booking_id: data.booking_id,
            service_name: data.service_name,
            booking_date: data.booking_date ? moment(data.booking_date).format("DD MMM, YYYY") : "NA",
            status: data.status,
            status_label : "0 for pending, 1 for ongoing, completed",
            amount: data.amount,
            case_id : data.case_id,
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
            updatetime: moment(data.updatetime).format("DD-MM-YYYY HH:mm A")
        }));
        return response.status(200).json({ success: true, msg: message.msgDataFound, booking_arr });
    });
};

const getBookingStatusWise = (request, response) => {
    const { user_id } = request.query;
    if (!user_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'user_id' });
    }
    const baseSelect = `SELECT bm.booking_id, bm.user_id, bm.vendor_id, bm.booking_date, bm.case_id, bm.service_id, bm.amount, bm.status, bm.service_name, bm.appointment_date, bm.createtime, bm.updatetime, vm.name as vendor_name, vm.mobile as vendor_mobile, vm.image as vendor_image, sm.image as service_image FROM booking_master bm LEFT JOIN user_master vm ON bm.vendor_id = vm.user_id LEFT JOIN service_master sm ON bm.service_id = sm.service_id WHERE bm.user_id = ? AND bm.delete_flag = 0`;
    // Ongoing (status=0 or 1)
    connection.query(baseSelect + ' AND (bm.status = 0 OR bm.status = 1) ORDER BY bm.booking_id DESC', [user_id], (err1, ongoingResult) => {
        if (err1) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: err1.message });
        }
        // Completed (status=2)
        connection.query(baseSelect + ' AND bm.status = 2 ORDER BY bm.booking_id DESC', [user_id], (err2, completedResult) => {
            if (err2) {
                return response.status(200).json({ success: false, msg: message.internalServerError, error: err2.message });
            }
            // Cancelled (status=3)
            connection.query(baseSelect + ' AND bm.status = 3 ORDER BY bm.booking_id DESC', [user_id], (err3, cancelledResult) => {
                if (err3) {
                    return response.status(200).json({ success: false, msg: message.internalServerError, error: err3.message });
                }
                const ongoing = (ongoingResult || []).map(data => ({
                    booking_id: data.booking_id,
                    user_id: data.user_id,
                    vendor_id: data.vendor_id,
                    vendor_name: data.vendor_name || 'NA',
                    vendor_mobile: data.vendor_mobile || 'NA',
                    vendor_image: data.vendor_image || 'NA',
                    service_image: data.service_image || 'NA',
                    booking_date: data.booking_date ? moment(data.booking_date).format("DD/MM/YYYY") : "NA",
                    case_id: data.case_id,
                    service_id: data.service_id,
                    amount: data.amount,
                    status: data.status,
                    status_label: "0/1 for ongoing",
                    service_name: data.service_name,
                    appointment_date: data.appointment_date ? moment(data.appointment_date).format("DD/MM/YYYY") : "NA",
                    createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A")
                }));
                const completed = (completedResult || []).map(data => ({
                    booking_id: data.booking_id,
                    user_id: data.user_id,
                    vendor_id: data.vendor_id,
                    vendor_name: data.vendor_name || 'NA',
                    vendor_mobile: data.vendor_mobile || 'NA',
                    vendor_image: data.vendor_image || 'NA',
                    service_image: data.service_image || 'NA',
                    booking_date: data.booking_date ? moment(data.booking_date).format("DD/MM/YYYY") : "NA",
                    case_id: data.case_id,
                    service_id: data.service_id,
                    amount: data.amount,
                    status: data.status,
                    status_label: "2 for completed",
                    service_name: data.service_name,
                    appointment_date: data.appointment_date ? moment(data.appointment_date).format("DD/MM/YYYY") : "NA",
                    createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A")
                }));
                const cancelled = (cancelledResult || []).map(data => ({
                    booking_id: data.booking_id,
                    user_id: data.user_id,
                    vendor_id: data.vendor_id,
                    vendor_name: data.vendor_name || 'NA',
                    vendor_mobile: data.vendor_mobile || 'NA',
                    vendor_image: data.vendor_image || 'NA',
                    service_image: data.service_image || 'NA',
                    booking_date: data.booking_date ? moment(data.booking_date).format("DD/MM/YYYY") : "NA",
                    case_id: data.case_id,
                    service_id: data.service_id,
                    amount: data.amount,
                    status: data.status,
                    status_label: "3 for cancelled",
                    service_name: data.service_name,
                    appointment_date: data.appointment_date ? moment(data.appointment_date).format("DD MMM, YYYY") : "NA",
                    createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A")
                }));
                return response.status(200).json({ success: true, msg: message.msgDataFound, ongoing : ongoing.length > 0 ? ongoing : "NA", completed : completed.length > 0 ? completed : "NA", cancelled  : cancelled.length > 0 ? cancelled : "NA"});
            });
        });
    });
};

const cancelBooking = (request, response) => {
    const { booking_id } = request.body;
    if (!booking_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'booking_id' });
    }
    const checkSql = "SELECT booking_id FROM booking_master WHERE booking_id = ? AND delete_flag = 0";
    connection.query(checkSql, [booking_id], (checkErr, checkResult) => {
        if (checkErr) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: checkErr.message });
        }
        if (!checkResult || checkResult.length === 0) {
            return response.status(200).json({ success: false, msg:message.bookingNotFound});
        }
        const sqlUpdate = "UPDATE booking_master SET status = 3, updatetime = NOW() WHERE booking_id = ?";
        connection.query(sqlUpdate, [booking_id], (error, result) => {
            if (error) {
                return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
            }
            if (result.affectedRows === 0) {
                return response.status(200).json({ success: false, msg:message.bookingNotFound });
            }
            return response.status(200).json({ success: true, msg: message.bookingCancelled});
        });
    });
};

const rescheduleBooking = (request, response) => {
    const { booking_id, new_appointment_date } = request.body;
    if (!booking_id || !new_appointment_date) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'booking_id or new_appointment_date' });
    }
    const checkSql = "SELECT booking_id FROM booking_master WHERE booking_id = ? AND delete_flag = 0";
    connection.query(checkSql, [booking_id], (checkErr, checkResult) => {
        if (checkErr) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: checkErr.message });
        }
        if (!checkResult || checkResult.length === 0) {
            return response.status(200).json({ success: false, msg: message.bookingNotFound });
        }
        const sqlUpdate = "UPDATE booking_master SET appointment_date = ?, updatetime = NOW() WHERE booking_id = ?";
        connection.query(sqlUpdate, [new_appointment_date, booking_id], (error, result) => {
            if (error) {
                return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
            }
            if (result.affectedRows === 0) {
                return response.status(200).json({ success: false, msg: message.bookingNotFound });
            }
            return response.status(200).json({ success: true, msg: message.bookingRescheduled });
        });
    });
};

const addBooking = (request, response) => {
    const { user_id, service_id, amount, appointment_date, service_name, service_type_id } = request.body;
    if (!user_id || !service_id || !amount || !appointment_date || !service_name || !service_type_id ) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'user_id, vendor_id, service_id, amount, appointment_date, service_name, or booking_date, or service_type_id' });
    }
    // Generate 10-digit numeric case_id
    const case_id = Math.floor(1000000000 + Math.random() * 9000000000).toString();
    var booking_date = appointment_date;
    const sqlInsert = `INSERT INTO booking_master (user_id, service_id, amount, appointment_date, service_name, booking_date, case_id, status, createtime, updatetime, delete_flag, service_type_id) VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW(), NOW(), 0)`;
    connection.query(sqlInsert, [user_id, service_id, amount, appointment_date, service_name, booking_date, case_id, service_type_id], (error, result) => {
        if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        return response.status(200).json({ success: true, msg:message.serviceBookedSuccess, booking_id: result.insertId, case_id, booking_date });
    });
};

const getContent = (request, response) => {
    const query = "SELECT content_id, content_type, content FROM content_master WHERE delete_flag = 0";
    connection.query(query, (err, rows) => {
        if (err) {
            return response.status(200).json({ success: false, error: message.internalServerError });
        }
        let webservice_url = "http://localhost:3003/fixfly/server/userApi";
        const content_arr = rows.map(row => ({
            content_id: row.content_id,
            content_type: row.content_type, 
            content: row.content,
            content_url: `${webservice_url}/get_all_content_url?content_type=${row.content_type}`,
            status: false 
        }));
        if (content_arr.length === 0) {
            const content_arr = 'NA';
            return response.status(200).json({ success: true, message: message.msgDataFound , content_arr });
        }
        return response.status(200).json({ success: true, message: message.msgDataFound , content_arr });
    });
};
const getAllContentUrl = (request, response) => {
    try {
        const { content_type } = request.query;
        const query1 = "SELECT content_id, content_type, content FROM content_master WHERE delete_flag = 0 AND content_type = ? ";
        const val1 = [content_type];
        connection.query(query1, val1, (valError, valResult) => {
            if (valError) {
                return response.status(200).json({ success: false, msg: message.internalServerError });
            }
            if (valResult.length === 0) {
                return response.status(200).json({ success: false, msg: message.msgDataNotFound });
            }
            let content_en;
                content_en = valResult[0].content
            let new12 = '<html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src * data: gap: content:"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui"><title>Data</title></head><body style="word-break: break-all;">' + content_en + '</body></html>';
            return response.send(new12);
        });
    } catch (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError });
    }
};

const getHomePageApi = (request, response) => {
    const { user_id } = request.query;
    if (!user_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'user_id' });
    }
    try {
        // Check if user exists
        const userSql = "SELECT user_id FROM user_master WHERE user_id = ? AND delete_flag = 0";
        connection.query(userSql, [user_id], async (userErr, userRows) => {
            if (userErr) {
                return response.status(200).json({ success: false, msg: message.internalServerError, error: userErr.message });
            }
            if (!userRows || userRows.length === 0) {
                return response.status(200).json({ success: false, msg: message.userNotFound });
            }
            // Fetch homepage data
            try {
                const banner_arr = await getBannerFunction();
                const top_product_arr = await getTopProduct();
                const recent_booking_arr = await getRecentBooking();
                const service_arr = await getServiceTypeWithServices();
                const top_rating_service_arr = await getTopRatingtServiceTypeWithService();
                return response.status(200).json({ success: true, msg: message.msgDataFound, banner_arr, top_product_arr, recent_booking_arr , service_arr, top_rating_service_arr});
            } catch (err) {
                return response.status(200).json({ success: false, msg: message.internalServerError, error: err.message });
            }
        });
    } catch (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
    }
};

function getBannerFunction() {
    return new Promise((resolve, reject) => {
        var sqlSelect = "SELECT banner_id, image FROM banner_master WHERE delete_flag = 0";
        connection.query(sqlSelect, (error, resultBanner) => {
            if (error) {
                return reject(error.message);
            }
            if (!resultBanner || resultBanner.length === 0) {
                return resolve("NA");
            } else {
                return resolve(resultBanner);
            }
        });
    });
}

function getTopProduct() {
    return new Promise((resolve, reject) => {
        var sqlSelect = "SELECT product_id, name, price, image FROM product_master WHERE delete_flag = 0 ORDER BY price DESC LIMIT 5";
        connection.query(sqlSelect, (error, resultProduct) => {
            if (error) {
                return reject(error.message);
            }
            if (!resultProduct || resultProduct.length === 0) {
                return resolve("NA");
            } else {
                return resolve(resultProduct);
            }
        });
    });
}

function getRecentBooking() {
    return new Promise((resolve, reject) => {
        var sqlSelect = `SELECT b.booking_id, b.case_id, b.service_id, s.service_name, s.image as service_image, b.appointment_date, b.booking_date, b.status, b.amount, b.createtime, b.updatetime FROM booking_master b LEFT JOIN service_master s ON b.service_id = s.service_id WHERE b.delete_flag = 0 ORDER BY b.booking_id DESC LIMIT 5`;
        connection.query(sqlSelect, (error, resultBooking) => {
            if (error) {
                return reject(error.message);
            }
            if (!resultBooking || resultBooking.length === 0) {
                return resolve("NA");
            } else {
                return resolve(resultBooking);
            }
        });
    });
}

async function getServiceTypeWithServices() {
    return new Promise((resolve, reject) => {
        const typeSql = "SELECT service_type_id, service_type FROM service_type_master WHERE delete_flag = 0 ORDER BY service_type_id DESC";
        connection.query(typeSql, [], (typeErr, typeRows) => {
            if (typeErr) {
                return reject(typeErr);
            }
            if (!typeRows || typeRows.length === 0) {
                return resolve("NA");
            }
            const serviceSql = "SELECT service_id, service_name, service_type_id, description, image, price FROM service_master WHERE delete_flag = 0 ORDER BY service_id DESC";
            connection.query(serviceSql, [], (serviceErr, serviceRows) => {
                if (serviceErr) {
                    return reject(serviceErr);
                }
                const typeArr = typeRows.map(type => {
                    const services = serviceRows.filter(s => s.service_type_id === type.service_type_id).map(s => ({
                        service_id: s.service_id,
                        service_name: s.service_name,
                        image: s.image,
                        description: s.description,
                        price: s.price
                    }));
                    return {
                        service_type_id: type.service_type_id,
                        service_type: type.service_type,
                        services: services.length > 0 ? services : "NA"
                    };
                });
                return resolve(typeArr);
            });
        });
    });
}

async function getTopRatingtServiceTypeWithService() {
    return new Promise((resolve, reject) => {
        // Get top 5 service types by average rating (from booking_rating_mster.service_id)
        const sql = `
            SELECT st.service_type_id, st.service_type, AVG(br.rating) as avg_rating
            FROM service_type_master st
            JOIN service_master s ON st.service_type_id = s.service_type_id AND s.delete_flag = 0
            JOIN booking_rating_mster br ON s.service_id = br.service_id AND br.delete_flag = 0
            WHERE st.delete_flag = 0
            GROUP BY st.service_type_id
            ORDER BY avg_rating DESC
            LIMIT 5
        `;
        connection.query(sql, [], (err, typeRows) => {
            if (err) {
                return reject(err);
            }
            if (!typeRows || typeRows.length === 0) {
                return resolve("NA");
            }
            // Get all services for these types, with their avg_rating from booking_rating_mster
            const typeIds = typeRows.map(t => t.service_type_id);
            if (typeIds.length === 0) return resolve("NA");
            const serviceSql = `SELECT s.service_id, s.service_name, s.service_type_id, s.description, s.image, s.price, AVG(br.rating) as avg_rating FROM service_master s LEFT JOIN booking_rating_mster br ON s.service_id = br.service_id AND br.delete_flag = 0 WHERE s.delete_flag = 0 AND s.service_type_id IN (${typeIds.map(() => '?').join(',')}) GROUP BY s.service_id ORDER BY s.service_id DESC`;
            connection.query(serviceSql, typeIds, (serviceErr, serviceRows) => {
                if (serviceErr) {
                    return reject(serviceErr);
                }
                const typeArr = typeRows.map(type => {
                    const services = serviceRows.filter(s => s.service_type_id === type.service_type_id).map(s => ({
                        service_id: s.service_id,
                        service_name: s.service_name,
                        image: s.image,
                        description: s.description,
                        price: s.price,
                        avg_rating: s.avg_rating !== null ? Number(s.avg_rating) : 0
                    }));
                    return {
                        service_type_id: type.service_type_id,
                        service_type: type.service_type,
                        services: services.length > 0 ? services : "NA"
                    };
                });
                return resolve(typeArr);
            });
        });
    });
}

const getServiceDetails = (request, response) => {
    const { service_id } = request.query;
    if (!service_id) {
        return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_id' });
    }
    // Get main service details
    const sql = "SELECT service_id, service_name, service_type_id, description, image, price FROM service_master WHERE service_id = ? AND delete_flag = 0";
    connection.query(sql, [service_id], (err, rows) => {
        if (err) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: err.message });
        }
        if (!rows || rows.length === 0) {
            return response.status(200).json({ success: false, msg: message.msgDataNotFound });
        }
        const service = rows[0];
        // Get avg rating for this service
        const ratingSql = "SELECT AVG(rating) as avg_rating FROM booking_rating_mster WHERE service_id = ? AND delete_flag = 0";
        connection.query(ratingSql, [service_id], (ratingErr, ratingRows) => {
            if (ratingErr) {
                return response.status(200).json({ success: false, msg: message.internalServerError, error: ratingErr.message });
            }
            const avg_rating = ratingRows && ratingRows[0] && ratingRows[0].avg_rating !== null ? Number(ratingRows[0].avg_rating) : 0;
            service.avg_rating = avg_rating;
            // Get relevant services (same type, not this one)
            const relSql = `SELECT s.service_id, s.service_name, s.image, s.price, s.description, AVG(br.rating) as avg_rating FROM service_master s LEFT JOIN booking_rating_mster br ON s.service_id = br.service_id AND br.delete_flag = 0 WHERE s.service_type_id = ? AND s.service_id != ? AND s.delete_flag = 0 GROUP BY s.service_id ORDER BY s.service_id DESC LIMIT 5`;
            connection.query(relSql, [service.service_type_id, service_id], (relErr, relRows) => {
                if (relErr) {
                    return response.status(200).json({ success: false, msg: message.internalServerError, error: relErr.message });
                }
                const relevant_services = (relRows && relRows.length > 0)
                    ? relRows.map(s => ({
                        service_id: s.service_id,
                        service_name: s.service_name,
                        image: s.image,
                        price: s.price,
                        description: s.description,
                        avg_rating: s.avg_rating !== null ? Number(s.avg_rating) : 0
                    }))
                    : "NA";
                return response.status(200).json({
                    success: true,
                    msg: message.msgDataFound,
                    service_detail: service,
                    relevant_services
                });
            });
        });
    });
};


module.exports = {getBanner,signIn, getFaq, getCategory, getSubCategory, createUserProfile, createTicket, getSubscription,purchasePlan, getProduct, getProductDetail, getProductRatings,getProductsByCategorySubcategory,getTicket,getClosedTicket,addProductRatingReview, getUserPlan,getBooking,getBookingStatusWise,cancelBooking,rescheduleBooking,getContent, getAllContentUrl, addBooking,getHomePageApi, getServiceDetails}