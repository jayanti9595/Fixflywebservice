var express = require("express");
const upload = require("../controller/multer");
const { getFaq, getCategory, getSubCategory, createTicket, getSubscription, purchasePlan, adminLoginController, getAdminAllData, UpdateAdminProfile, UpdateAdminPassword, addCategory, deleteCategory, editCategory ,addSubCategory, deleteSubCategory, editSubCategory, getAllFaq, getAllFaqById, addFAQ, deleteFaq, editFaq, CheckAdminEmail, AdminForgetPassword, getAllUserDataController, ViewUserDetails, getTotalUserCount, getAllDeletedUser, fetchaboutcontent, updateContent, getProduct, getProductDetail, addProduct, deleteProduct, editProduct, getAllVendorDataController, getAllDeletedVendorDataController, ActivateDeactivateUser, getBanner, addBanner, deleteBanner, editBanner, getSelectedSubCategory, getService, getServiceDetail, addService, deleteService, editService, getServiceType, addServiceType, editServiceType, deleteServiceType, getBooking, getVendorName, addAMCPlan, getAms, getAmsDetail, editAms, assignVendor, getBookingDetail, getTicketData, SendMail, updateStatus} = require("../controller/userController");
var router = express.Router();

router.get("/get_faq",getFaq)
router.get("/get_category",getCategory);
router.get("/get_sub_category",getSubCategory);
router.get("/get_selected_sub_category",getSelectedSubCategory);
router.get("/get_admin_data",getAdminAllData);
router.post("/admin_login",upload.none(),adminLoginController);
router.post("/create_ticket",upload.none(),createTicket);
router.post("/edit_admin_profile",upload.single("image"),UpdateAdminProfile);
router.post("/update_admin_password",upload.none(),UpdateAdminPassword);
router.get("/get_subscription",getSubscription);
router.post("/purchase_plan",upload.none(),purchasePlan);
router.post("/add_category",upload.single("image"),addCategory);
router.post("/delete_category",deleteCategory);
router.post("/edit_category",upload.single("image"),editCategory);
router.post("/add_sub_category",upload.single("image"),addSubCategory);
router.post("/delete_sub_category",upload.none(),deleteSubCategory);
router.post("/edit_sub_category",upload.single("image"),editSubCategory);
router.get("/get_all_faq",getAllFaq);
router.get("/view_faq_by_id",getAllFaqById);
router.post("/add_faq",upload.none(),addFAQ)
router.post("/delete_faq",upload.none(),deleteFaq);
router.post("/edit_faq",upload.none(),editFaq);
router.post("/Check_admin_email",upload.none(),CheckAdminEmail);
router.post("/Admin_forget_password",upload.none(),AdminForgetPassword);
router.get("/get_all_user_data",upload.none(),getAllUserDataController);
router.get("/get_user_data/:user_id",ViewUserDetails);
router.get("/get_user_total_count",getTotalUserCount);
router.get("/get_deleted_all_user_data",getAllDeletedUser);
router.get("/fetchaboutcontent",fetchaboutcontent);
router.post("/updateContent",upload.none(),updateContent);
router.get("/get_product",getProduct);
router.get("/get_product_detail",getProductDetail);
router.post("/add_product",upload.single('image'),addProduct);
router.post("/delete_product",upload.none(),deleteProduct);
router.post("/edit_product",upload.single('image'),editProduct);
router.get("/get_all_vendor_data",upload.none(),getAllVendorDataController);
router.get("/get_all_deleted_vendor_data",upload.none(),getAllDeletedVendorDataController);
router.post("/ActivateDeactivateUser", upload.none(), ActivateDeactivateUser);
router.get("/get_banner", getBanner);
router.post("/add_banner", upload.fields([{ name: "image" }]), addBanner);
router.post("/delete_banner", upload.none(), deleteBanner);
router.post("/edit_banner", upload.fields([{ name: "image" }, { name: "video" }]), editBanner);

// Service Routes
router.get("/get_service_type", getServiceType);
router.post("/add_service_type", upload.none(), addServiceType);
router.post("/delete_service_type", upload.none(), deleteServiceType);
router.post("/edit_service_type", upload.none(), editServiceType);

// Service Master Routes
router.get("/get_services", getService);
router.get("/get_service_detail", getServiceDetail);
router.post("/add_service", upload.single('image'), addService);
router.post("/delete_service", upload.none(), deleteService);
router.post("/edit_service", upload.single('image'), editService);
router.post('/add_amc_plan',upload.none(), addAMCPlan);
router.get("/get_Booking", getBooking);
router.get("/get_vendor_name",getVendorName);
router.get("/get_ams", getAms);
router.get("/get_ams_detail", getAmsDetail);
router.post("/edit_ams", upload.none(), editAms);
router.post("/assign_vendor", upload.none(), assignVendor)
router.get("/get_booking_detail", getBookingDetail);
router.get("/get_ticket", getTicketData);
router.post("/send_mail", upload.none(), SendMail);
router.post("/update_status", upload.none(), updateStatus);
module.exports = router;