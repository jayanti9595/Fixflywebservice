const nodemailer = require('nodemailer');
var moment = require("moment");

// var mailSMTPSecure = "ssl";
// var transporter = nodemailer.createTransport({
//     service: 'gmail',
//     host: "fixfly.in@gmail.com",
//     port: 465,
//     secure: mailSMTPSecure === "ssl",
//     auth: {
//         user: "fixfly.in@gmail.com",
//         pass: "ticketxoxsoyplajdmsdqi_id",
//     },
//     tls: {
//         rejectUnauthorized: false,
//     },
// });

function mailBodyForgetPassword(postData) {
    const year = new Date().getFullYear();
    const mailBody = `<!DOCTYPE html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta charset="UTF-8">
        <title>Welcome to ${postData.app_name}</title>
    </head>
    <body style="margin: 0; padding: 0; font-size:13px; color:#444; font-family:Arial, Helvetica, sans-serif; padding-top:70px; padding-bottom:70px;">
        <table cellspacing="0" cellpadding="0" align="center" width="768" class="outer-tbl" style="margin:0 auto;">
        <tr>
            <td class="pad-l-r-b" style="background-color:#ECEFF1; padding:0 70px 40px;">
                <table cellpadding="0" cellspacing="0" class="full-wid">
                </table>
                <table cellpadding="0" cellspacing="0" style="width:100%; background-color:#FFFFFF; border-radius:4px;box-shadow:0 0 20px #ccc;margin-top:40px">
                <tr>
                <td>
                    <table border="0" style="margin:0; width:100%" cellpadding="0" cellspacing="0">
                        <tr style=" background-color : #10f0ca">
                            <td class="logo" style="padding:25px 0 30px 0; text-align:center; border-bottom:1px solid #E1E1E1"; background-color : #10f0ca>
                                <img src=${postData.app_logo} alt="" width="20%" >
                                <h2 style="color : #FFFFFF">Forgot Your Password</h2>
                               
                            </td>
                        </tr>
                        <tr><td></td></tr>  
                        <tr>
                            <td class="content" style="padding:40px 40px;">
                                <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0"> Dear <b> ${postData.adminName}, </b></p>
                                <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0"> <b> Email : </b> ${postData.adminEmail} ,</p>
                    <br /><br />
                                <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0"> </b>Recently a request was submitted to reset a password for your account. if this was a mistake, just ignore this email and nothing will happen. </p>
                                <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0"> </b>To reset your password, visit the following link </p>
                                <br />
                                <center>
                                    <button style="border:none">  <a href="http://localhost:3000/fixfly/admin/resetpassword/${postData.encodedUserId}" style="display: inline-block; padding: 10px 20px; border-radius: 10px; border: none; background: #10f0ca; color: #fff; text-decoration: none; text-align: center;">
                                        Reset Password
                                    </a></button>
                                </center>
                                <br /><br />
                                <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0; font-weight:bold">
                                Regards,                    
                                </p>
                                <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0;  font-weight:bold">
                                ${postData.app_name} App Team
                                </p>
                            </td>
                        </tr>
                        <tr>                
                            <td style="background-color : #10f0ca; padding-bottom:60px;">
                                <table style="width:100%" border="0" cellspacing="0" cellpadding="0" class="full-wid" align="center">
                                <tr>
                                    <td>     
                                        <div style="margin:0 auto; text-align:center; padding:0 100px" class="foot-items">
                                            <p style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#ffffff; margin-top:40px; line-height:20px;">
                                            &#169;   ${year} ${postData.app_name} App Team |  All right Reserved
                                            </p>
                                            <p style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; line-height:20px; margin-bottom:40px;">
                                            <p style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#fff; line-height:20px;">
                                                This email and any files transmitted with it are confidential and intended solely for the use of the individual or entity to whom they are addressed. 
                                                If you have received this email in error, please notify the system manager. This message contains confidential information and is intended only for the individual named. 
                                                If you are not the named addressee, you should not disseminate, distribute or copy this email. Please notify the sender immediately by email if you have received this email by mistake and delete this email from your system. 
                                                If you are not the intended recipient, you are notified that disclosing, copying, distributing or taking any action in reliance on the contents of this information is strictly prohibited.
                                            </p>
                                        </div>
                                    </td>
                                </tr>
                                </table>
                            </td>
                        </tr>              
                    </table>
                </td>
                </tr>   
            </table>
        </td>
        </tr>   
        </table>
    </body>
    </html>`;
    return mailBody;
}
async function ForgetPasswordMail(email, subject, mailBody) {
    const mailOptions = {
        from: "support@meribhiapp.com",
        to: email,
        subject: subject,
        html: mailBody,
    };
    try {
        // Use transporter to send email
        const info = await transporter.sendMail(mailOptions);
        return {
            success: true,
            message: "Forget password email sent successfully.",
            info,
        };
    } catch (error) {
        return {
            success: false,
            message: "Failed to send forget password email.",
            error: error.message,
        };
    }
}

function mailBodyActivateDeactivateUser(postData) {
    const year = new Date().getFullYear();
    const mailBody = `<!DOCTYPE html>
      <head>
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
          <meta charset="UTF-8">
          <title>Welcome to ${postData.app_name}</title>
      </head>
      <body style="margin: 0; padding: 0; font-size:13px; color:#444; font-family:Arial, Helvetica, sans-serif; padding-top:70px; padding-bottom:70px;">
          <table cellspacing="0" cellpadding="0" align="center" width="768" class="outer-tbl" style="margin:0 auto;">
          <tr>
              <td class="pad-l-r-b" style="background-color:#ECEFF1; padding:0 70px 40px;">
                  <table cellpadding="0" cellspacing="0" class="full-wid">
                  </table>
                  <table cellpadding="0" cellspacing="0" style="width:100%; background-color:#FFFFFF; border-radius:4px;box-shadow:0 0 20px #ccc;margin-top:40px">
                  <tr>
                  <td>
                      <table border="0" style="margin:0; width:100%" cellpadding="0" cellspacing="0">
                          <tr style=" background-color : #10f0ca">
                              <td class="logo" style="padding:25px 0 30px 0; text-align:center; border-bottom:1px solid #E1E1E1">
                                  <img src=${postData.app_logo} alt="" width="20%" >
                                  <h2 style="color : #FFFFFF">Account Informartion</h2>
                                 
                              </td>
                          </tr>
                          <tr><td></td></tr>  
                          <tr>
                              <td class="content" style="padding:40px 40px;">
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0"> Dear <b> ${postData.userName}, </b></p>
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0"> Your Message App Account has been ${postData.newStatusMsg} by Admin</p>
            
                                  <br /><br />
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0; font-weight:bold">
                                  Regards,                    
                                  </p>
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0;  font-weight:bold">
                                  ${postData.app_name} App Team
                                  </p>
                              </td>
                          </tr>
                          <tr>                
                              <td style="background-color: #10f0ca; padding-bottom:60px;">
                                  <table style="width:100%" border="0" cellspacing="0" cellpadding="0" class="full-wid" align="center">
                                  <tr>
                                      <td>     
                                          <div style="margin:0 auto; text-align:center; padding:0 100px" class="foot-items">
                                              <p style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#ffffff; margin-top:40px; line-height:20px;">
                                              &#169;   ${year} ${postData.app_name} App team |  All right Reserved
                                              </p>
                                              <p style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; line-height:20px; margin-bottom:40px;">
                                              <p style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#fff; line-height:20px;">
                                                  This email and any files transmitted with it are confidential and intended solely for the use of the individual or entity to whom they are addressed. 
                                                  If you have received this email in error, please notify the system manager. This message contains confidential information and is intended only for the individual named. 
                                                  If you are not the named addressee, you should not disseminate, distribute or copy this email. Please notify the sender immediately by email if you have received this email by mistake and delete this email from your system. 
                                                  If you are not the intended recipient, you are notified that disclosing, copying, distributing or taking any action in reliance on the contents of this information is strictly prohibited.
                                              </p>
                                          </div>
                                      </td>
                                  </tr>
                                  </table>
                              </td>
                          </tr>              
                      </table>
                  </td>
                  </tr>   
              </table>
          </td>
          </tr>   
          </table>
      </body>
      </html>`;
    return mailBody;
}
// Activate Deactivate
async function ActivateDeactivateMail(email, subject, mailBody) {
    const mailOptions = {
        from: "fixfly.in@gmail.com",
        to: email,
        subject: subject,
        html: mailBody,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log("Email sent:", info);
        return {
            success: true,
            message: "Email sent successfully.",
            info,
        };
    } catch (error) {
        console.error("Error sending email:", error);
        return {
            success: false,
            message: "Failed to send email.",
            error: error.message,
        };
    }
}

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'fixfly.in@gmail.com',
    pass: 'ticketxoxsoyplajdmsdqi_id',
  },
});

async function ActivateDeactivateMailUser(email, subject, mailBody) {
  const mailOptions = {
    from: "fixfly.in@gmail.com",
    to: email,
    subject: subject,
    html: mailBody,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log("Email sent:", info);
    return {
      success: true,
      message: "Email sent successfully.",
      info,
    };
  } catch (error) {
    console.error("Error sending email:", error);
    return {
      success: false,
      message: "Failed to send email.",
      error: error.message,
    };
  }
}
async function sendMail(email, subject, mailBody) {
    const mailOptions = {
      from: "fixfly.in@gmail.com",
      to: email,
      subject: subject,
      html: mailBody,
    };
    try {
      const info = await transporter.sendMail(mailOptions);
      return { success: true, message: "Email sent successfully", info };
    } catch (error) {
      return {
        success: false,
        message: "Failed to send email",
        error: error.message,
      };
    }
  }

function mailBodyContactUs(postData) {
    const year = new Date().getFullYear();
    const mailBody = `<!DOCTYPE html>
      <head>
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
          <meta charset="UTF-8">
          <title>Welcome to ${postData.app_name}</title>
      </head>
      <body style="margin: 0; padding: 0; font-size:13px; color:#444; font-family:Arial, Helvetica, sans-serif; padding-top:70px; padding-bottom:70px;">
          <table cellspacing="0" cellpadding="0" align="center" width="768" class="outer-tbl" style="margin:0 auto;">
          <tr>
              <td class="pad-l-r-b" style="background-color:#ECEFF1; padding:0 70px 40px;">
                  <table cellpadding="0" cellspacing="0" class="full-wid">
                  </table>
                  <table cellpadding="0" cellspacing="0" style="width:100%; background-color:#FFFFFF; border-radius:4px;box-shadow:0 0 20px #ccc;margin-top:40px">
                  <tr>
                  <td>
                      <table border="0" style="margin:0; width:100%" cellpadding="0" cellspacing="0">
                          <tr style=" background-color : #10f0ca">
                              <td class="logo" style="padding:25px 0 30px 0; text-align:center; border-bottom:1px solid #E1E1E1">
                                  <img src=${postData.app_logo} alt="" width="20%" >
                                  <h2 style="color : #FFFFFF">Contact to ${postData.user_name}</h2>
                              </td>
                          </tr>
                          <tr><td></td></tr>  
                          <tr>
                              <td class="content" style="padding:40px 40px;">
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0"> Dear <b> ${postData.user_name}, </b></p>
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0"><b>${postData.title}</b> </p>
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0">Thank you for reaching out to us. We have received your message, and our team has reviewed your inquiry.</p>
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0">${postData.newMsg} </p>
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0; font-weight:bold">
                                  Best regards,
                                  </p>
                                  <p style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#333333; margin-top:0;  font-weight:bold">
                                  ${postData.app_name} App
                                  </p>
                              </td>
                          </tr>
                          <tr>                
                              <td style="background-color: #10f0ca; padding-bottom:60px;">
                                  <table style="width:100%" border="0" cellspacing="0" cellpadding="0" class="full-wid" align="center">
                                  <tr>
                                      <td>     
                                          <div style="margin:0 auto; text-align:center; padding:0 100px" class="foot-items">
                                              <p style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#ffffff; margin-top:40px; line-height:20px;">
                                              &#169;   ${year} ${postData.app_name} |  All right Reserved
                                              </p>
                                              <p style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; line-height:20px; margin-bottom:40px;">
                                              <p style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#fff; line-height:20px;">
                                                  This email and any files transmitted with it are confidential and intended solely for the use of the individual or entity to whom they are addressed. 
                                                  If you have received this email in error, please notify the system manager. This message contains confidential information and is intended only for the individual named. 
                                                  If you are not the named addressee, you should not disseminate, distribute or copy this email. Please notify the sender immediately by email if you have received this email by mistake and delete this email from your system. 
                                                  If you are not the intended recipient, you are notified that disclosing, copying, distributing or taking any action in reliance on the contents of this information is strictly prohibited.
                                              </p>
                                          </div>
                                      </td>
                                  </tr>
                                  </table>
                              </td>
                          </tr>              
                      </table>
                  </td>
                  </tr>   
              </table>
          </td>
          </tr>   
          </table>
      </body>
      </html>`;
    return mailBody;
  }
  // forget password
  
module.exports = { ForgetPasswordMail, mailBodyForgetPassword, mailBodyActivateDeactivateUser, ActivateDeactivateMailUser, mailBodyContactUs, sendMail }