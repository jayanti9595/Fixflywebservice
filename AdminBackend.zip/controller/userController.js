const connection = require("../connection/dbConfig");
const message = require("./language")
const axios = require('axios');
const crypto = require("crypto");
const rs = require("randomstring");
const jwt = require("jsonwebtoken");
var moment = require("moment");
const { mailBodyForgetPassword, ForgetPasswordMail, mailBodyActivateDeactivateUser, ActivateDeactivateMailUser, sendMail, mailBodyContactUs } = require("./mailer");
require('dotenv').config()
var SECRET_KEY = process.env.SECRET_KEY;
const signIn = async (request, response) => {
  const { mobile } = request.body;
  try {
    if (!mobile) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "mobile" });
    }
    const otp = 123456;
    const msg91Payload = {
      authkey: "your_authkey",
      mobile: `91${mobile}`,
      otp: otp,
      sender: "SENDER",
      template_id: "your_template_id"
    };
    try {
      await axios.post("https://control.msg91.com/api/v5/otp", msg91Payload, {
        headers: { "Content-Type": "application/json" }
      });
      const insertSql = "INSERT INTO user_master(mobile, otp, updatetime, createtime) VALUES (?, ?, NOW(), NOW())";
      connection.query(insertSql, [mobile, otp], (error, insertResult) => {
        if (error) {
          return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
        }
        return response.status(200).json({ success: true, msg: "OTP sent successfully to new user." });
      });
    } catch (msg91Err) {
      return response.status(200).json({ success: false, msg: "Failed to send OTP", err: msg91Err.message });
    }

  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
  }
};

const getFaq = (request, response) => {
  try {
    var sqlSelect = "SELECT faq_id,question,answer FROM faq_master WHERE delete_flag = 0";
    connection.query(sqlSelect, (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: err.message })
      }
      var faq_arr = [];
      if (result.length > 0) {
        for (var data of result) {
          faq_arr.push({
            faq_id: data.faq_id,
            question: data.question,
            answer: data.answer,
            status: false
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, faq_arr: faq_arr.length > 0 ? faq_arr : "NA" })
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, faq_arr: "NA" })
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
  }
}

const getCategory = (request, response) => {
  try {
    var sqlSelect = "SELECT category_id,name,image FROM category_master WHERE delete_flag = 0 order by category_id desc";
    connection.query(sqlSelect, (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
      }
      var category_arr = [];
      if (result.length > 0) {
        for (var data of result) {
          category_arr.push({
            category_id: data.category_id,
            name: data.name,
            image: data.image,
            status: false,
            createtime: moment(data.createtime).format("DD-MM-YYY hh:mm A")
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, category_arr: category_arr.length > 0 ? category_arr : "NA" })
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, category_arr: "NA" })
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
  }
}

const getSubCategory = (request, response) => {
  try {
    var sqlSelect = "SELECT scm.sub_category_id,scm.category_id,scm.name,scm.image FROM sub_category_master as scm JOIN category_master as cm ON scm.category_id = cm.category_id WHERE scm.delete_flag = 0 AND cm.delete_flag = 0";
    connection.query(sqlSelect, async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: err.message })
      }
      var sub_category_arr = [];
      if (result.length > 0) {
        for (var data of result) {
          sub_category_arr.push({
            sub_category_id: data.sub_category_id,
            category_id: data.category_id,
            name: data.name,
            category_name: await getCategoryName(data.category_id),
            image: data.image,
            createtime: moment(data.createtime).format("DD-MM-YYY hh:mm A"),
            status: false
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, sub_category_arr: sub_category_arr.length > 0 ? sub_category_arr : "NA" })
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, sub_category_arr: "NA" })
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
  }
}

const getSelectedSubCategory = (request, response) => {
  const { category_id } = request.query;
  try {
    var sqlSelect = "SELECT scm.sub_category_id,scm.category_id,scm.name,scm.image FROM sub_category_master as scm JOIN category_master as cm ON scm.category_id = cm.category_id WHERE scm.delete_flag = 0 AND cm.delete_flag = 0 AND scm.category_id = ?";
    connection.query(sqlSelect, [category_id], async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: err.message })
      }
      var sub_category_arr = [];
      if (result.length > 0) {
        for (var data of result) {
          sub_category_arr.push({
            sub_category_id: data.sub_category_id,
            category_id: data.category_id,
            name: data.name,
            category_name: await getCategoryName(data.category_id),
            image: data.image,
            createtime: moment(data.createtime).format("DD-MM-YYY hh:mm A"),
            status: false
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, sub_category_arr: sub_category_arr.length > 0 ? sub_category_arr : "NA" })
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, sub_category_arr: "NA" })
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
  }
}

async function getCategoryName(category_id) {
  return new Promise((resolve, reject) => {
    const sqlSelect = "SELECT name FROM category_master WHERE category_id = ? AND delete_flag = 0";

    connection.query(sqlSelect, [category_id], (error, results) => {
      if (error) {
        return reject(error);
      }

      if (results.length > 0) {
        resolve(results[0].name);
      } else {
        resolve("NA");
      }
    });
  });
}

async function getSubCategoryName(sub_category_id) {
  return new Promise((resolve, reject) => {
    const sqlSelect = "SELECT name FROM sub_category_master WHERE sub_category_id = ? AND delete_flag = 0";

    connection.query(sqlSelect, [sub_category_id], (error, results) => {
      if (error) {
        return reject(error);
      }

      if (results.length > 0) {
        resolve(results[0].name);
      } else {
        resolve("NA");
      }
    });
  });
}

async function getServiceTypeData(service_type_id) {
  return new Promise((resolve, reject) => {
    if (!service_type_id) {
      resolve("NA");
      return;
    }

    const sqlSelect = "SELECT service_type_id, service_type FROM service_type_master WHERE service_type_id = ? AND delete_flag = 0";

    connection.query(sqlSelect, [service_type_id], (error, results) => {
      if (error) {
        return reject(error);
      }

      if (results.length > 0) {
        resolve(results[0].service_type);
      } else {
        resolve("NA");
      }
    });
  });
}

const createUserProfile = (request, response) => {
  const { name, mobile, city, pincode, street } = request.body;
  try {
    if (!name) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "name" })
    }
    if (!mobile) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "mobile" })
    }
    if (!city) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "city" })
    }
    if (!street) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "street" })
    }
    if (!pincode) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "pincode" })
    }
    var sqlSelect = "SELECT active_flag FROM user_master WHERE mobile = ? AND delete_flag = 0";
    connection.query(sqlSelect, [mobile], (error, resultUser) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
      }
      if (resultUser.length > 0) {
        var updateUserData = "UPDATE user_master SET user_type = ?, name = ?, city= ?,pincode = ?, street = ?,updatetime = NOW() WHERE mobile = ? AND delete_flag = 0";
        connection.query(updateUserData, [1, name, city, pincode, street, mobile], (error, updateResult) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
          }
          return response.status(200).json({ success: true, msg: message.dataUpdated })
        })
      } else {
        var updateUserData = "INSERT INTO user_master(mobile,name,user_type,city,pincode, street,updatetime,createtime) VALUES (?,?,?,?,?,?,NOW(),NOW())";
        connection.query(updateUserData, [mobile, name, 1, city, pincode, street], (error, insertResult) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
          }
          return response.status(200).json({ success: true, msg: message.dataUpdated })
        })
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
  }
}

const createTicket = (request, response) => {
  const { user_id, ticket_tag_id, issue_desc } = request.body;
  try {
    if (!user_id) {
      return response.status(200).json({ success: true, msg: message.empt_params, key: "user_id" })
    }
    if (!ticket_tag_id) {
      return response.status(200).json({ success: true, msg: message.empt_params, key: "ticket_tag" })
    }
    if (!issue_desc) {
      return response.status(200).json({ success: true, msg: message.empt_params, key: "issue_desc" })
    }
    var sqlSelect = "INSERT INTO ticket_master(user_id,ticket_tag_id,issue_description,createtime,updatetime) VALUES (?,?,?,NOW(),NOW())";
    connection.query(sqlSelect, [user_id, ticket_tag_id, issue_desc], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
      }
      return response.status(200).json({ success: true, meg: message.ticketAdded })
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
  }
}

const getSubscription = (request, response) => {
  const { user_id } = request.query;
  try {
    if (!user_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "user_id" })
    }
    var sqlSelect = "SELECT user_id FROM user_master WHERE delete_flag = 0 AND user_id = ?";
    connection.query(sqlSelect, [user_id], async (error, userResult) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
      }
      if (userResult.length <= 0) {
        return response.status(200).json({ success: false, msg: message.userNotFound })
      }
      if (userResult[0].active_flag == 1) {
        return response.status(200).json({ success: false, msg: message.userAccountDeactivate })
      }
      var subscription_arr = [];
      if (userResult.length > 0) {
        var sqlSelect = "SELECT subscription_id,no_of_day,plan_name,plan_description FROM subscription_master WHERE delete_flag = 0";
        connection.query(sqlSelect, async (error, subscriptionResult) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
          }
          if (subscriptionResult.length > 0) {
            for (var data of subscriptionResult) {
              subscription_arr.push({
                subscription_id: data.subscription_id,
                no_of_day: data.no_of_day,
                plan_name: data.plan_name,
                plan_description: data.plan_description,
              })
            }
            return response.status(200).json({ success: true, msg: message.msgDataFound, subscription_arr: subscription_arr.length > 0 ? subscription_arr : "NA" })
          } else {
            return response.status(200).json({ success: true, msg: message.msgDataFound, subscription_arr: "NA" })
          }
        })
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message })
  }
}

const purchasePlan = async (request, response) => {
  const { user_id, no_of_day, subscription_id, plan_name, plan_description, transation_id } = request.body;
  try {
    if (!user_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "user_id" });
    }
    if (!no_of_day) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "no_of_day" });
    }
    if (!subscription_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "subscription_id" });
    }
    if (!plan_name) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "plan_name" });
    }
    if (!plan_description) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "plan_description" });
    }
    if (!transation_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "transation_id" });
    }
    const sqlSelect = "SELECT user_id, active_flag FROM user_master WHERE user_id = ? AND delete_flag = 0";
    connection.query(sqlSelect, [user_id], (error, userResult) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
      }
      if (!userResult || userResult.length === 0) {
        return response.status(200).json({ success: false, msg: message.userNotFound });
      }
      if (userResult[0].active_flag === 1) {
        return response.status(200).json({ success: false, msg: message.userAccountDeactivate });
      }
      const start_date = new Date();
      const end_date = new Date(start_date);
      end_date.setDate(end_date.getDate() + parseInt(no_of_day));
      const insertSQL = `INSERT INTO user_plan_master (user_id, no_of_day, start_date, end_date, subscription_id, plan_name, plan_description,transation_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
      connection.query(insertSQL, [user_id, no_of_day, start_date, end_date, subscription_id, plan_name, plan_description, transation_id], (error, resultInsert) => {
        if (error) {
          return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
        }
        return response.status(200).json({ success: true, msg: message.planPurchased });
      });
    });

  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
  }
};

const adminLoginController = async (request, response) => {
  const { email, password } = request.body;
  try {
    if (!email) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "email" });
    }
    if (!password) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "password" });
    }
    const sqlCheckUser = "SELECT user_id,email,username, password, privileges, active_flag, mobile, address, user_type FROM user_master WHERE email = ? AND delete_flag = 0 AND user_type IN (0,3)";
    connection.query(sqlCheckUser, [email], async (err, userResult) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: err.message });
      }
      if (userResult.length <= 0) {
        return response.status(200).json({ success: false, msg: message.emailNotRegistered, key: "email" });
      }
      if (userResult.length > 0) {
        var adminPassword = userResult[0].password;
        const hashedPass = await hashPassword(password);
        if (adminPassword != hashedPass) {
          return response.status(200).json({ success: false, msg: message.emailNotRegistered, key: "password" });
        } else {
          const payload = { subject: userResult[0].user_id };
          const token = jwt.sign(payload, SECRET_KEY, { expiresIn: "7d" });
          return response.status(200).json({ success: true, msg: message.loginSuccessfully, key: "login_successfully", token: token, info: userResult });
        }
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, err: error.message });
  }
};
async function hashPassword(pass) {
  return crypto.createHash("sha256").update(pass).digest("hex");
}

const getAdminAllData = async (request, response) => {
  try {
    const sqlCheckUser = "SELECT user_id,email,username, password, user_id, active_flag, mobile, address, user_type,image FROM user_master WHERE user_type = 0 AND delete_flag = 0 ";
    connection.query(sqlCheckUser, async (err, userResult) => {
      if (err) {
        return response
          .status(200)
          .json({
            success: false,
            msg: message.internalServerError,
            err: err.message,
          });
      }
      if (userResult.length <= 0) {
        return response
          .status(200)
          .json({
            success: false,
            msg: message.msgDataNotFound,
            key: "email",
          });
      }
      if (userResult.length > 0) {
        return response
          .status(200)
          .json({
            success: true,
            msg: message.msgDataFound,
            key: "data found",
            info: userResult,
          });
      }
    });
  } catch (error) {
    return response.status(200).json({
      success: false,
      msg: message.internalServerError,
      err: error.message,
    });
  }
};


const UpdateAdminProfile = async (request, response) => {
  const { name, email } = request.body;
  try {
    let image = request.file ? request.file.filename : null;
    if (!name || !email) {
      return response
        .status(200)
        .json({ success: false, msg: message.empt_params });
    }
    let updateQuery = "UPDATE user_master SET username = ?, email = ?";
    let params = [name, email];
    if (image) {
      updateQuery += ", image = ?";
      params.push(image);
    }
    updateQuery += `WHERE user_type = 0 AND delete_flag = 0 `;
    connection.query(updateQuery, params, (err, result) => {
      if (err) {
        return response
          .status(200)
          .json({
            success: false,
            msg: message.internalServerError,
            err: err.message,
          });
      }
      if (result.affectedRows > 0) {
        return response
          .status(200)
          .json({
            success: true,
            msg: "Admin profile updated successfully.",
            key: "Edit",
          });
      } else {
        return response
          .status(200)
          .json({ success: false, msg: "Failed to update profile." });
      }
    });
  } catch (error) {
    return response
      .status(200)
      .json({
        success: false,
        msg: lang.internalServerError,
        error: error.message,
      });
  }
};

// update admin password
const UpdateAdminPassword = async (request, response) => {
  const { oldpassword, newPassword } = request.body;
  try {
    if (!oldpassword) {
      return response.status(200).json({
        success: false,
        msg: message.empt_params,
        key: "old_password",
      });
    }
    if (!newPassword) {
      return response.status(200).json({
        success: false,
        msg: message.empt_params,
        key: "new_password",
      });
    }
    var sql =
      "SELECT user_id FROM user_master WHERE user_type = 0  and delete_flag = 0";
    connection.query(sql, async (err, info) => {
      if (err) {
        return response
          .status(200)
          .json({ success: false, msg: message.internalServerError });
      }
      if (info.length <= 0) {
        return response
          .status(200)
          .json({ success: false, msg: message.msgUserNotFound });
      }
      if (info[0].active_flag === 0) {
        return response.status(200).json({
          success: false,
          msg: message.userAccountDeactivate,
          active_status: 0,
        });
      }
      console.log(info[0].user_id);
      var sqlforget = "select password from user_master where user_id = ?";
      connection.query(sqlforget, [info[0].user_id], async (err, data) => {
        if (err) {
          return response
            .status(200)
            .json({ success: false, msg: message.internalServerError });
        } else {
          if (data.length <= 0) {
            return response
              .status(200)
              .json({ success: false, msg: message.msgDataNotFound });
          }
          var password = data[0].password;
          console.log(password);
          const old_password_hash = await hashPassword(oldpassword);

          if (password === old_password_hash) {
            const new_pass = await hashPassword(newPassword);
            if (new_pass != old_password_hash) {
              var updateSql = "UPDATE user_master SET password=?, updatetime = NOW() WHERE user_id = ? AND delete_flag = 0";
              connection.query(updateSql, [new_pass, info[0].user_id], (err) => {
                if (err) {
                  return response.status(200).json({ success: false, msg: message.internalServerError });
                } else {
                  return response.status(200).json({ success: true, msg: message.PasswordUpdatedSuccessfully, key: "success" });
                }
              });
            } else {
              return response.status(200).json({
                success: true,
                msg: message.newOldPassword,
                key: "samePassword",
              });
            }
          } else {
            return response.status(200).json({
              success: false,
              msg: message.newOldPassword,
              key: "failure",
            });
          }
        }
      });
    });
  } catch (error) {
    return response
      .status(200)
      .json({ success: false, msg: message.internalServerError });
  }
};

// const getPetType = async (request, response) => {
//   try {
//     var sqlSelect = "SELECT category_id,image, 	pet_type, DATE_FORMAT(createtime, '%d-%m-%Y %h:%i %p') AS formatted_createtime FROM pet_type_master WHERE delete_flag = 0 order by category_id desc";

//     connection.query(sqlSelect, async (error, result) => {
//       if (error) {
//         return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
//       }
//       if (result.length > 0) {
//         return response.status(200).json({ success: true, msg: message.msgDataFound, result: result })
//       } else {
//         return response.status(200).json({ success: true, msg: message.msgDataFound, result: [] })
//       }
//     })
//   } catch (error) {
//     return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
//   }
// }


const addCategory = async (request, response) => {
  const { category_name } = request.body;
  if (!category_name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'category_name' });
  }
  let image = request.file ? request.file.filename : null;
  if (!image) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'image' });
  }
  try {
    var sqlSlect = "SELECT * FROM category_master WHERE LOWER(name) = LOWER(?) AND delete_flag = 0";
    connection.query(sqlSlect, [category_name], async (error, resultEnglish) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      if (resultEnglish.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: "english_title" });
      } else {
        const insertQuery = `INSERT INTO category_master (name, image, createtime, updatetime) VALUES (?, ?, NOW(), NOW())`;
        const values = [category_name, image];
        connection.query(insertQuery, values, (error, result) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
          }
          if (result.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: message.categoryEditSuccess });
          } else {
            return response.status(200).json({ success: false, msg: message.categoryEditUnSuccess });
          }
        });
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const deleteCategory = async (request, response) => {
  const { category_id } = request.body;
  try {
    if (!category_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "category_id" })
    }
    var deleteSQL = "UPDATE category_master SET delete_flag  = 1, updatetime = now() WHERE category_id = ? AND delete_flag  = 0";
    connection.query(deleteSQL, [category_id], async (error, result) => {
      if (error) {
        const record = { success: false, msg: message.internalServerError, error: error.message };
        return response.json(record);
      }
      if (result.affectedRows > 0) {
        const record = { success: true, msg: message.deleteFaqSuccess };
        return response.json(record);
      } else {
        const record = { success: true, msg: message.errorDeleteFaqSuccess };
        return response.json(record);
      }
    })
  } catch (error) {
    const record = { success: false, msg: message.internalServerError, error: error.message };
    return response.json(record);
  }
}


const editCategory = async (request, response) => {
  const { category_id, name, } = request.body;

  if (!name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'name' });
  }

  if (!category_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'category_id' });
  }

  let image = request.file ? request.file.filename : null;

  try {
    var sqlSlect = "SELECT * FROM category_master WHERE LOWER(name) = LOWER(?) AND delete_flag = 0 AND category_id != ? ";
    connection.query(sqlSlect, [name, category_id], async (error, resultEnglish) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      if (resultEnglish.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: "english_title" });
      } else {
        const insertQuery = (image == null) ? `UPDATE category_master SET name = ?,  updatetime = NOW() WHERE category_id = ? AND delete_flag = 0` : `UPDATE category_master SET name = ?, image = ? ,  updatetime = NOW() WHERE category_id = ? AND delete_flag = 0`;
        const values = (image == null) ? [name, category_id] : [name, image, category_id];
        connection.query(insertQuery, values, (error, result) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
          }
          if (result.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: message.categoryEditSuccess });
          } else {
            return response.status(200).json({ success: false, msg: message.categoryEditUnSuccess });
          }
        });
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const addSubCategory = async (request, response) => {
  const { sub_category_name, category_id } = request.body;
  if (!sub_category_name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'sub_category_name' });
  }
  if (!category_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'category_id' });
  }
  let image = request.file ? request.file.filename : null;
  if (!image) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'image' });
  }
  try {
    var sqlSlect = "SELECT * FROM sub_category_master WHERE LOWER(name) = LOWER(?) AND delete_flag = 0";
    connection.query(sqlSlect, [sub_category_name], async (error, resultEnglish) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      if (resultEnglish.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: "english_title" });
      } else {
        const insertQuery = `INSERT INTO sub_category_master (category_id,name, image, createtime, updatetime) VALUES (?,?, ?, NOW(), NOW())`;
        const values = [category_id, sub_category_name, image];
        connection.query(insertQuery, values, (error, result) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
          }
          if (result.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: message.categoryEditSuccess });
          } else {
            return response.status(200).json({ success: false, msg: message.categoryEditUnSuccess });
          }
        });
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};


const deleteSubCategory = async (request, response) => {
  const { sub_category_id } = request.body;
  try {
    if (!sub_category_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "sub_category_id" })
    }
    var deleteSQL = "UPDATE sub_category_master SET delete_flag  = 1, updatetime = now() WHERE sub_category_id = ? AND delete_flag  = 0";
    connection.query(deleteSQL, [sub_category_id], async (error, result) => {
      if (error) {
        const record = { success: false, msg: message.internalServerError, error: error.message };
        return response.json(record);
      }
      if (result.affectedRows > 0) {
        const record = { success: true, msg: message.deleteFaqSuccess };
        return response.json(record);
      } else {
        const record = { success: true, msg: message.errorDeleteFaqSuccess };
        return response.json(record);
      }
    })
  } catch (error) {
    const record = { success: false, msg: message.internalServerError, error: error.message };
    return response.json(record);
  }
}

const editSubCategory = async (request, response) => {
  const { category_id, name, sub_category_id } = request.body;

  if (!name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'name' });
  }
  if (!category_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'category_id' });
  }
  if (!sub_category_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'sub_category_id' });
  }

  let image = request.file ? request.file.filename : null;
  console.log("images", image);


  try {
    const sqlSelect = `
      SELECT * FROM sub_category_master 
      WHERE LOWER(name) = LOWER(?) AND delete_flag = 0 AND sub_category_id != ?
    `;

    connection.query(sqlSelect, [name, sub_category_id], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: 'name' });
      }

      const sqlUpdate = image == null
        ? `UPDATE sub_category_master SET category_id = ?, name = ?, updatetime = NOW() WHERE sub_category_id = ? AND delete_flag = 0`
        : `UPDATE sub_category_master SET category_id = ?, name = ?, image = ?, updatetime = NOW() WHERE sub_category_id = ? AND delete_flag = 0`;

      const values = image == null
        ? [category_id, name, sub_category_id]
        : [category_id, name, image, sub_category_id];

      connection.query(sqlUpdate, values, (error, updateResult) => {
        if (error) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }

        if (updateResult.affectedRows > 0) {
          return response.status(200).json({ success: true, msg: message.categoryEditSuccess });
        } else {
          return response.status(200).json({ success: false, msg: message.categoryEditUnSuccess });
        }
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};


const getAllFaq = async (request, response) => {
  try {
    var sqlSelect = "SELECT faq_id, question, answer, createtime FROM faq_master WHERE delete_flag = 0 order by faq_id desc";

    connection.query(sqlSelect, async (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: err.message });
      }
      var faq_arr = [];
      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, faq_arr: faq_arr });
      }
      var s_no = 0;
      for (var data of result) {
        s_no++;
        faq_arr.push({
          s_no: s_no,
          faq_id: data.faq_id,
          answer: data.answer,
          question: data.question,
          createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
        });
      }
      return response.status(200).json({ success: true, msg: message.msgDataFound, faq_arr: faq_arr });
    });
  } catch (error) {
    return response
      .status(200)
      .json({ success: false, msg: message.internalServerError });
  }
}

const getAllFaqById = async (request, response) => {
  const { faq_id } = request.query;
  try {
    if (!faq_id) {
      const record = { 'success': false, 'msg': message.empt_params, 'key': 'faq_id' }
      return res.json(record);
    }
    var sqlSelect = "SELECT faq_id, question, answer, createtime FROM faq_master WHERE delete_flag = 0 AND faq_id = ? order by faq_id desc";

    connection.query(sqlSelect, [faq_id], async (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError });
      }
      var faq_arr = {};
      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, faq_arr: faq_arr });
      }
      if (result.length > 0) {
        var data = result[0];
        faq_arr = {
          faq_id: data.faq_id,
          question: data.question,
          answer: data.answer,
          createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
        };
        return response.status(200).json({ success: true, msg: message.msgDataFound, faq_arr: faq_arr });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError });
  }
}

const deleteFaq = async (request, response) => {

  const { faq_id } = request.body;

  try {

    if (!faq_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "faq_id" });
    }

    var sqlSelect = "SELECT faq_id,question, answer, createtime FROM faq_master WHERE delete_flag = 0 AND faq_id = ?";
    connection.query(sqlSelect, [faq_id], async (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound });
      }

      if (result.length > 0) {
        var updateSql = "UPDATE faq_master set delete_flag = 1 , updatetime = now() where delete_flag = 0 AND faq_id = ?";
        connection.query(updateSql, [faq_id], (err, updateQuestion) => {
          if (err) {
            return response.status(200).json({ success: false, msg: message.internalServerError });
          }
          if (updateQuestion.affectedRows <= 0) {
            return response.status(200).json({ success: false, msg: "Error deleteing faq" });
          }
          if (updateQuestion.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: message.deleteFaqSuccess });
          }
        });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const addFAQ = async (request, response) => {
  const { question, answer } = request.body;
  try {
    if (!question) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "question" });
    }
    if (!answer) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "answer" });
    }
    const checkDuplicateName = "SELECT faq_id,question, answer, createtime FROM faq_master WHERE delete_flag = 0 AND LOWER(question) = LOWER(?);";
    connection.query(checkDuplicateName, [question], (duplicateErr2, duplicateRes1) => {

      if (duplicateErr2) {
        return response.status(200).json({ success: false, msg: message.internalServerError, key: "2" });
      }

      if (duplicateRes1.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: "FaqAlreadyExist" });
      }
      const insertQuestion = "INSERT INTO faq_master(question,answer,createtime,updatetime) VALUES (?,?,now(),now())";
      connection.query(insertQuestion, [question, answer], (updateError, result) => {
        if (updateError) {
          return response.status(200).json({ success: false, msg: message.internalServerError, updateError: updateError.message });
        }
        if (result.affectedRows <= 0) {
          return response.status(200).json({ success: false, msg: message.errorUpdating });
        }
        return response.status(200).json({ success: true, msg: message.FaqAddSucessfully });
      });
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, key: "4", error: error.message });
  }
}

const editFaq = async (request, response) => {
  const { faq_id, question, answer } = request.body;

  try {
    if (!faq_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "faq_id" });
    }

    if (!question) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "question" });
    }

    if (!answer) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: "answer" });
    }


    const checkCategory = "SELECT faq_id,question, answer, createtime FROM faq_master WHERE delete_flag = 0 AND delete_flag = 0 AND faq_id = ?";
    connection.query(checkCategory, [faq_id], (err, res) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, key: "1" });
      }
      if (res.length === 0) {
        return response.status(200).json({ success: false, msg: message.msgDataNotFound, key: "faqNotFound" });
      }

      const checkDuplicateName = "SELECT faq_id, question FROM faq_master WHERE delete_flag = 0 AND LOWER(question) = LOWER(?) AND faq_id != ?";
      connection.query(checkDuplicateName, [question, faq_id], (duplicateErr, duplicateRes) => {
        if (duplicateErr) {
          return response.status(200).json({ success: false, msg: message.internalServerError, key: "2" });
        }
        if (duplicateRes.length > 0) {
          return response.status(200).json({ success: false, msg: message.msgDataFound, key: "faqAlreadyExist" });
        }

        const updateCategory = "UPDATE faq_master set question = ?, answer = ?, updatetime = now()  WHERE delete_flag = 0 AND faq_id = ?";
        connection.query(updateCategory, [question, answer, faq_id], async (updateError, result) => {
          if (updateError) {
            return response.status(200).json({ success: false, msg: message.internalServerError, key: "3" });
          }
          if (result.affectedRows <= 0) {
            return response.status(200).json({ success: false, msg: message.errorUpdating });
          }
          return response.status(200).json({ success: true, msg: message.DetailsUpdated });
        });
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message, key: "4" });
  }
}
const CheckAdminEmail = async (request, response) => {
  const { email } = request.body;
  if (!email) {
    return response.status(200).json({ success: false, msg: message.empt_params });
  }
  try {
    var check = "SELECT email FROM user_master WHERE email = ? AND user_type = 0  AND delete_flag = 0";
    connection.query(check, [email], async (err, res) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError });
      }
      if (res.length <= 0) {
        return response.status(200).json({ success: false, msg: message.msgDataNotFound });
      }
      if (res.length > 0) {
        return response.status(200).json({ success: true, msg: message.msgDataFound, res: res[0].email });
      } else {
        return response.status(200).json({ success: false, msg: message.msgDataNotFound });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const AdminForgetPassword = async (request, response) => {
  const { email } = request.body;
  // Check if email is provided
  if (!email) {
    return response.status(200).json({ success: false, msg: "Email is required.", key: "email" });
  }
  try {
    const sql = "SELECT user_id, username, email FROM user_master WHERE email = ? AND user_type = 0 AND delete_flag = 0";
    connection.query(sql, [email], async (err, results) => {
      if (err) {
        return response.status(200).json({ success: false, msg: "Database error occurred.", error: err.message });
      }
      if (results.length === 0) {
        return response.status(200).json({ success: false, msg: "User not found for given email.", key: "email" });
      }
      const adminEmail = results[0].email;
      const adminName = results[0].username;
      const subject = "Forget Password";
      const app_name = "FixFly";
      const app_logo = process.env.APP_LOGO;

      const encodedUserId = crypto.createHash('md5').update(Date.now().toString()).digest('hex').slice(0, 8);

      const mailBody = mailBodyForgetPassword({ adminName, adminEmail, subject, app_logo, app_name, encodedUserId });
      try {
        const mailRes = await ForgetPasswordMail(adminEmail, subject, mailBody);
        if (mailRes.success) {
          const sql = "UPDATE user_master SET unique_code = ?, unique_status = 0 WHERE email = ? AND user_type = 0 AND delete_flag = 0";
          connection.query(sql, [encodedUserId, email], async (err, results) => {
            if (err) {
              return response.status(200).json({
                success: false,
                msg: "Database error occurred.",
                error: err.message
              });
            }

            // Check if any row was updated
            if (results.affectedRows === 0) {
              return response.status(404).json({
                success: false,
                msg: "User not found for the given email.",
                key: "email"
              });
            }

            return response.status(200).json({
              success: true,
              msg: "Forgot password email sent successfully.",
              data: { adminName, adminEmail, subject, app_logo, app_name, encodedUserId }
            });
          });


        } else {
          return response.status(200).json({
            success: false,
            msg: "Failed to send forget password email.",
            error: mailRes.error,
          });
        }
      } catch (emailError) {
        return response.status(200).json({
          success: false,
          msg: "Error sending forget password email.",
          error: emailError.message,
        });
      }
    });
  } catch (error) {
    return response.status(200).json({
      success: false,
      msg: "Unexpected error occurred.",
      error: error.message,
    });
  }
};


const getAllUserDataController = async (request, response) => {
  try {
    const sqlCheckUser =
      "SELECT user_id,last_login_date_time, login_type, user_type,image, f_name, l_name, username, name, dob, age, phone_code, city, mobile, otp, otp_verify, email, password, image, address, latitude, longitude, pincode, active_flag, gender, notification_status, instagram_id, createtime, updatetime, account_deactive_by FROM user_master WHERE delete_flag = 0 AND profile_complete = 1 AND otp_verify = 1 AND user_type = 1 ORDER BY user_id DESC";

    connection.query(sqlCheckUser, async (err, userResult) => {
      if (err) {
        return response.status(200).json({
          success: false,
          msg: message.internalServerError,
          err: err.message,
        });
      }

      var user_arr = [];
      if (userResult.length <= 0) {
        return response.status(200).json({
          success: true,
          msg: message.msgDataFound,
          user_arr: user_arr,
        });
      }

      var s_no = 0;
      if (userResult.length > 0) {
        for (var data of userResult) {
          // var img = await fetchUserImage(data.user_id);
          s_no++;
          user_arr.push({
            s_no: s_no,
            user_id: data.user_id,
            username: data.username,
            f_name: data.f_name,
            l_name: data.l_name,
            name: data.name,
            email: data.email,
            image: data.image,
            address: data.address,
            latitude: data.latitude,
            longitude: data.longitude,
            phone_code: data.phone_code,
            dob: data.dob ? moment(data.dob).format("DD/MM/YYYY") : "NA",
            mobile: data.mobile,
            active_flag: data.active_flag,
            last_login_date_time: moment(data.last_login_date_time).format("DD-MM-YYYY HH:mm A"),
            active_flag_lable:
              data.active_flag == 1 ? "Activate" : "Deactivate",
            account_deactive_by: data.account_deactive_by,
            account_deactive_by_status:
              data.account_deactive_by == 1 ? "Admin" : "User",
            city_name: (data.city != null) ? data.city : "NA",
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
          });
        }

        return response.status(200).json({
          success: true,
          msg: message.msgDataFound,
          user_arr: user_arr.length > 0 ? user_arr : "NA",
        });
      }
    });
  } catch (error) {
    return response.status(200).json({
      success: false,
      msg: message.internalServerError,
      err: error.message,
    });
  }
};


const ViewUserDetails = async (request, response) => {
  const { user_id } = request.params;
  if (!user_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: "user_id" });
  }

  var checkUser = "SELECT user_id, active_flag FROM user_master WHERE user_id = ?";
  connection.query(checkUser, [user_id], async (err, res) => {
    if (err) {
      return response.status(200).json({ success: false, msg: message.internalServerError });
    }
    if (res.length <= 0) {
      return response.status(200).json({ success: false, msg: message.userNotFound });
    }
    if (res[0].active_flag === 0) {
      return response.status(200).json({ success: false, msg: message.userAccountDeactivate });
    }
    if (res.length > 0) {
      var FetchDetails = "SELECT * FROM user_master WHERE user_id = ?";
      connection.query(FetchDetails, [user_id], async (err, userResult) => {
        if (err) {
          return response.status(200).json({ success: false, msg: message.internalServerError });
        } else {
          if (userResult.length > 0) {
            var user_arr = [];
            var data = userResult[0];
            user_arr.push({
              user_id: data.user_id,
              username: data.username,
              f_name: data.f_name,
              l_name: data.l_name,
              name: data.name,
              email: data.email,
              image: data.image,
              address: data.address,
              city_name: (data.city != null) ? data.city : "NA",
              mobile: data.mobile,
              phone_code: data.phone_code,
              user_type: data.user_type,
              pincode: data.pincode,
              town: data.town,
              about: data.about,
              street: data.street,
              latitude: data.latitude,
              user_type_lable: "0=admin,1=user",
              active_flag: data.active_flag,
              last_login_date_time: moment(data.last_login_date_time).format("DD-MM-YYYY HH:mm A"),
              createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
              delete_flag: data.delete_flag,
            });
            return response.status(200).json({ success: true, msg: message.msgDataFound, res: user_arr });
          }
        }
      });
    } else {
      return response.status(200).json({ success: false, msg: message.msgUserNotFound });
    }
  });
};

const getTotalUserCount = async (request, response) => {
  try {
    const sqlCheckUser =
      "SELECT count(user_id) as user_count FROM user_master WHERE delete_flag = 0 AND user_type != 0 AND otp_verify = 1 AND profile_complete =1";
    connection.query(sqlCheckUser, async (err, userResult) => {
      if (err) {
        return response.status(200).json({
          success: false,
          msg: message.internalServerError,
          err: err.message,
        });
      }
      if (userResult.length <= 0) {
        return response.status(200).json({
          success: false,
          msg: message.msgDataFound,
          userResult: userResult,
        });
      }
      if (userResult.length > 0) {
        return response.status(200).json({
          success: true,
          msg: message.msgDataFound,
          userResult: userResult,
        });
      }
    });
  } catch (error) {
    return response.status(200).json({
      success: false,
      msg: message.internalServerError,
      err: error.message,
    });
  }
}
const getAllDeletedUser = async (request, response) => {
  try {
    const sqlCheckUser =
      "SELECT user_id, login_type,last_login_date_time, user_type,name, f_name, l_name, username, dob,country_id, age, city, phone_code, mobile,  otp, otp_verify, email, password, image, address, latitude, longitude, pincode, active_flag, gender,notification_status,delete_reason, instagram_id, createtime, updatetime FROM user_master WHERE user_type = 1 AND delete_flag = 1  order by user_id desc";
    connection.query(sqlCheckUser, async (err, userResult) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: err.message });
      }
      var user_arr = [];
      if (userResult.length <= 0) {
        return response.status(200).json({ success: true, msg: message.msgDataFound, user_arr: [] });
      }
      var s_no = 0;
      if (userResult.length > 0) {
        for (var data of userResult) {
          s_no++;
          user_arr.push({
            s_no: s_no,
            user_id: data.user_id,
            username: data.username,
            f_name: data.f_name,
            l_name: data.l_name,
            name: data.name,
            email: data.email,
            image: data.image,
            address: data.address,
            latitude: data.latitude,
            longitude: data.longitude,
            mobile: data.mobile,
            dob: data.dob ? moment(data.dob).format("DD/MM/YYYY") : 'NA',
            delete_reason: (data.delete_reason) ? data.delete_reason : "NA",
            active_flag: data.active_flag,
            country: (data.country_id != 0) ? await getCountryName(data.country_id) : "NA",
            city_name: (data.city != null) ? data.city : "NA",
            createtime: moment(data.updatetime).format("DD-MM-YYYY HH:mm A"),
            active_flag_lable: data.active_flag == 1 ? 'Activate' : 'Deactivate',
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, user_arr: user_arr.length > 0 ? user_arr : [] });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.msgDataFound });
  }
};

const fetchaboutcontent = async (request, response) => {
  const { contentType } = request.query;
  if (!contentType) {
    return response.status(200).json({ success: false, msg: message.empt_params });
  }
  try {
    var fetch = "SELECT content,content_1,content_3 FROM content_master WHERE content_type = ? AND delete_flag = 0";
    connection.query(fetch, [contentType], async (err, res) => {
      if (err) {
        return response.status(20).json({ success: false, smg: message.internalServerError });
      }
      if (res.length <= 0) {
        return response.status(200).json({ success: false, msg: message.msgDataNotFound });
      }
      if (res.length > 0) {
        return response.status(200).json({ success: true, msg: message.msgDataFound, res });
      } else {
        return response.status(200).json({ success: false, msg: message.msgDataNotFound });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError });
  }
};
//Update Content
const updateContent = async (request, response) => {
  const contentType = request.body.contentType;
  const content = request.body.content;
  const language = request.body.lang;
  if (contentType === undefined || content === undefined) {
    return response.status(200).json({ success: false, msg: message.msg_empty_param, key: "none" });
  }
  if (language === undefined) {
    return response.status(200).json({ success: false, msg: message.msg_empty_param, key: "language" });
  }
  const language_type = language === 0 ? "content" : language == 1 ? 'content_1' : "content_3";
  try {
    const check = "SELECT content_type FROM content_master WHERE content_type = ? AND delete_flag = 0";
    connection.query(check, [contentType], async (err, res) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError });
      }
      if (res.length <= 0) {
        return response.status(200).json({ success: false, msg: message.msgDataNotFound });
      }
      const updateQuery = `UPDATE content_master SET ${language_type} = ? WHERE content_type = ?`;
      connection.query(updateQuery, [content, contentType], async (err, res1) => {
        if (err) {
          return response.status(200).json({
            success: false, msg: message.internalServerError,
          });
        }
        if (res1.affectedRows > 0) {
          return response.status(200).json({ success: true, msg: message.ContentUpdated });
        } else {
          return response.status(200).json({ success: false, msg: "No rows affected" });
        }
      });
    });
  } catch (error) {
    return response
      .status(200)
      .json({ success: false, msg: message.internalServerError });
  }
};

const getProduct = async (request, response) => {
  try {
    var sqlSelect = "SELECT product_id,sub_category_id,category_id, name, image, price, createtime FROM product_master WHERE delete_flag = 0 order by product_id desc";
    connection.query(sqlSelect, async (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError });
      }
      var product_arr = [];
      if (result.length === 0) {
        return response.status(200).json({ success: true, msg: message.msgDataFound, product_arr: [] });
      }
      if (result.length > 0) {
        for (var data of result) {
          product_arr.push({
            product_id: data.product_id,
            name: data.name,
            image: data.image,
            price: data.price,
            category_id: data.category_id,
            sub_category_id: data.sub_category_id,
            category_name: await getCategoryName(data.category_id),
            sub_category_name: await getSubCategoryName(data.sub_category_id),
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
          })
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, product_arr: product_arr });
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, product_arr: [] });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError });
  }
}

const getProductDetail = async (request, response) => {
  const { product_id } = request.query;

  try {
    if (!product_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: 'product_id' });
    }

    var sqlSelect = "SELECT product_id, sub_category_id, category_id, name, image, price, createtime, updatetime FROM product_master WHERE product_id = ? AND delete_flag = 0";
    connection.query(sqlSelect, [product_id], async (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: err.message });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.noDataFound });
      }

      const data = result[0];
      const productDetail = {
        product_id: data.product_id,
        name: data.name,
        image: data.image,
        price: data.price,
        // description: data.description || "NA",
        // status: data.status,
        category_id: data.category_id,
        sub_category_id: data.sub_category_id,
        category_name: await getCategoryName(data.category_id),
        sub_category_name: await getSubCategoryName(data.sub_category_id),
        createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
        updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
      };

      return response.status(200).json({
        success: true,
        msg: message.msgDataFound,
        product_detail: productDetail
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
}

async function getCategoryName(category_id) {
  return new Promise((resolve, reject) => {
    const sqlSelect = "SELECT name FROM category_master WHERE category_id = ? AND delete_flag = 0";

    connection.query(sqlSelect, [category_id], (error, results) => {
      if (error) {
        return reject(error);
      }

      if (results.length > 0) {
        resolve(results[0].name);
      } else {
        resolve("NA");
      }
    });
  });
}

const addProduct = async (request, response) => {
  const { price, product_name, category_id, sub_category_id } = request.body;

  if (!product_name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'product_name' });
  }
  if (!category_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'category_id' });
  }
  if (!sub_category_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'sub_category_id' });
  }

  if (!price) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'price' });
  }

  let image = request.file ? request.file.filename : null;

  if (!image) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'image' });
  }

  try {
    const sqlCheck = "SELECT * FROM product_master WHERE LOWER(name) = LOWER(?) AND delete_flag = 0";
    connection.query(sqlCheck, [product_name], async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: "product_name" });
      } else {
        const insertQuery = `INSERT INTO product_master (name, image, sub_category_id, category_id, price, createtime, updatetime) VALUES (?, ?, ?, ?, ?, NOW(), NOW())`;
        const values = [product_name, image, sub_category_id, category_id, price];

        connection.query(insertQuery, values, (error, result) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
          }

          if (result.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: message.productAddSuccess });
          } else {
            return response.status(200).json({ success: false, msg: message.productAddFail });
          }
        });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};


const deleteProduct = async (request, response) => {
  const { product_id } = request.body;

  if (!product_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'product_id' });
  }

  try {
    const sqlCheck = "SELECT * FROM product_master WHERE product_id = ? AND delete_flag = 0";
    connection.query(sqlCheck, [product_id], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.noDataFound });
      }
      const deleteQuery = `UPDATE product_master SET delete_flag = 1, updatetime = NOW() WHERE product_id = ?`;
      connection.query(deleteQuery, [product_id], (error, deleteResult) => {
        if (error) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        return response.status(200).json({ success: true, msg: message.productDeleteSuccess });
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const editProduct = async (request, response) => {
  const { product_id, price, product_name, category_id, sub_category_id } = request.body;

  if (!product_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'product_id' });
  }
  if (!category_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'category_id' });
  }
  if (!sub_category_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'sub_category_id' });
  }

  if (!product_name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'product_name' });
  }

  if (!price) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'price' });
  }

  let image = request.file ? request.file.filename : null;

  try {
    // Check if product exists
    const sqlCheck = "SELECT * FROM product_master WHERE product_id = ? AND delete_flag = 0";
    connection.query(sqlCheck, [product_id], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.noDataFound });
      }

      // Check for duplicate product name (excluding current product)
      const duplicateCheck = "SELECT * FROM product_master WHERE LOWER(name) = LOWER(?) AND product_id != ? AND delete_flag = 0";
      connection.query(duplicateCheck, [product_name, product_id], (duplicateError, duplicateResult) => {
        if (duplicateError) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: duplicateError.message });
        }

        if (duplicateResult.length > 0) {
          return response.status(200).json({ success: false, msg: message.msgDataFound, key: "product_name" });
        }

        // Update product
        let updateQuery, values;
        if (image) {
          updateQuery = `UPDATE product_master SET sub_category_id = ?, category_id = ?, name = ?, price = ?, image = ?, updatetime = NOW() WHERE product_id = ? AND delete_flag = 0`;
          values = [sub_category_id, category_id, product_name, price, image, product_id];
        } else {
          updateQuery = `UPDATE product_master SET sub_category_id = ?, category_id = ?, name = ?, price = ?, updatetime = NOW() WHERE product_id = ? AND delete_flag = 0`;
          values = [sub_category_id, category_id, product_name, price, product_id];
        }

        connection.query(updateQuery, values, (updateError, updateResult) => {
          if (updateError) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: updateError.message });
          }

          if (updateResult.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: message.productEditSuccess });
          } else {
            return response.status(200).json({ success: false, msg: message.productEditFail });
          }
        });
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};


const getAllVendorDataController = async (request, response) => {
  try {
    const sqlCheckUser =
      "SELECT user_id,last_login_date_time, login_type, user_type,image, f_name, l_name, username, name, dob, age, phone_code, city, mobile, otp, otp_verify, email, password, image, address, latitude, longitude, pincode, active_flag, gender, notification_status, instagram_id, createtime, updatetime, account_deactive_by FROM user_master WHERE delete_flag = 0 AND profile_complete = 1 AND otp_verify = 1 AND user_type = 2 ORDER BY user_id DESC";

    connection.query(sqlCheckUser, async (err, userResult) => {
      if (err) {
        return response.status(200).json({
          success: false,
          msg: message.internalServerError,
          err: err.message,
        });
      }

      var user_arr = [];
      if (userResult.length <= 0) {
        return response.status(200).json({
          success: true,
          msg: message.msgDataFound,
          user_arr: user_arr,
        });
      }

      var s_no = 0;
      if (userResult.length > 0) {
        for (var data of userResult) {
          // var img = await fetchUserImage(data.user_id);
          s_no++;
          user_arr.push({
            s_no: s_no,
            user_id: data.user_id,
            username: data.username,
            f_name: data.f_name,
            l_name: data.l_name,
            name: data.name,
            email: data.email,
            image: data.image,
            address: data.address,
            latitude: data.latitude,
            longitude: data.longitude,
            phone_code: data.phone_code,
            dob: data.dob ? moment(data.dob).format("DD/MM/YYYY") : "NA",
            mobile: data.mobile,
            active_flag: data.active_flag,
            last_login_date_time: moment(data.last_login_date_time).format("DD-MM-YYYY HH:mm A"),
            active_flag_lable:
              data.active_flag == 1 ? "Activate" : "Deactivate",
            account_deactive_by: data.account_deactive_by,
            account_deactive_by_status:
              data.account_deactive_by == 1 ? "Admin" : "User",
            city_name: (data.city != null) ? data.city : "NA",
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
          });
        }

        return response.status(200).json({
          success: true,
          msg: message.msgDataFound,
          user_arr: user_arr.length > 0 ? user_arr : "NA",
        });
      }
    });
  } catch (error) {
    return response.status(200).json({
      success: false,
      msg: message.internalServerError,
      err: error.message,
    });
  }
};

const getAllDeletedVendorDataController = async (request, response) => {
  try {
    const sqlCheckUser =
      "SELECT user_id, login_type,last_login_date_time, user_type,name, f_name, l_name, username, dob,country_id, age, city, phone_code, mobile,  otp, otp_verify, email, password, image, address, latitude, longitude, pincode, active_flag, gender,notification_status,delete_reason, instagram_id, createtime, updatetime FROM user_master WHERE user_type = 2 AND delete_flag = 1  order by user_id desc";
    connection.query(sqlCheckUser, async (err, userResult) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: err.message });
      }
      var user_arr = [];
      if (userResult.length <= 0) {
        return response.status(200).json({ success: true, msg: message.msgDataFound, user_arr: [] });
      }
      var s_no = 0;
      if (userResult.length > 0) {
        for (var data of userResult) {
          s_no++;
          user_arr.push({
            s_no: s_no,
            user_id: data.user_id,
            name: data.name,
            email: data.email,
            image: data.image,
            address: data.address,
            latitude: data.latitude,
            longitude: data.longitude,
            mobile: data.mobile,
            dob: data.dob ? moment(data.dob).format("DD/MM/YYYY") : 'NA',
            delete_reason: (data.delete_reason) ? data.delete_reason : "NA",
            active_flag: data.active_flag,
            city_name: (data.city != null) ? data.city : "NA",
            createtime: moment(data.updatetime).format("DD-MM-YYYY HH:mm A"),
            active_flag_lable: data.active_flag == 1 ? 'Activate' : 'Deactivate',
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, user_arr: user_arr.length > 0 ? user_arr : [] });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.msgDataFound });
  }
};

const ActivateDeactivateUser = async (request, response) => {
  const data = request.body;
  const { user_id } = data;
  if (!user_id) {
    return response.status(200).json({ success: false, msg: "Missing user_id" });
  }
  try {
    const checkUserQuery = "SELECT * FROM user_master WHERE user_id = ? AND delete_flag = 0";
    connection.query(checkUserQuery, [user_id], async (err, res) => {
      if (err) {
        return response.status(200).json({ success: false, msg: "Internal server error" });
      }
      if (res.length === 0) {
        return response.status(200).json({ success: false, msg: "User not found" });
      }
      const user = res[0];
      const userName = user.name;
      const userEmail = user.email;
      const newActiveFlag = user.active_flag === 1 ? 0 : 1;
      const newStatusMsg = user.active_flag === 1 ? "Deactivated" : "Activated";

      const updateUserQuery = (user.active_flag === 1) ? "UPDATE user_master SET account_deactive_by = 1, active_flag = ? WHERE user_id = ?" : "UPDATE user_master SET account_deactive_by = 0 , active_flag = ? WHERE user_id = ?";
      connection.query(updateUserQuery, [newActiveFlag, user_id], async (err, result) => {
        if (err) {
          return response.status(200).json({ success: false, msg: "Internal server error" });
        }
        const { affectedRows } = result;
        if (affectedRows > 0) {
          const subject = "Account Info";
          const app_name = process.env.APP_NAME;
          const app_logo = process.env.APP_LOGO;
          const mailBody = mailBodyActivateDeactivateUser({ userName, newStatusMsg, app_name, app_logo });
          try {
            const mailResponse = await ActivateDeactivateMailUser(userEmail, subject, mailBody);
            if (mailResponse.success) {
              return response.status(200).json({ success: true, msg: message.EmailSent });
            } else {
              return response.status(200).json({ success: false, msg: "Error sending email " });
            }
          } catch (error) {
            return response.status(200).json({
              success: false, msg: "Failed to send email ",
            });
          }
        } else {
          return response.status(200).json({ success: false, msg: "Failed to update user status" });
        }
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: "Internal server error" });
  }
};

const getBanner = async (request, response) => {
  try {
    var sqlSelect = "SELECT banner_id, image, DATE_FORMAT(createtime, '%d-%m-%Y %h:%i %p') as createtime_format  FROM banner_master WHERE delete_flag = 0 order by banner_id desc";
    connection.query(sqlSelect, async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      return response.status(200).json({ success: true, msg: message.msgDataFound, banner_arr: result });
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
}

const addBanner = async (request, response) => {
  try {
    var images = request.files["image"];
    if (!images) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: 'images' });
    }
    var sqlInsert = "INSERT INTO banner_master(image,createtime,updatetime) VALUES (?,now(),now())";
    connection.query(sqlInsert, [images[0].filename], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      if (result.affectedRows > 0) {
        return response.status(200).json({ success: true, msg: message.bannerAddedSuccesfully })
      } else {
        return response.status(200).json({ success: false, msg: message.bannerAddedUnSuccesfully })
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
}

const deleteBanner = async (request, response) => {
  const { banner_id } = request.body;
  try {
    if (!banner_id) {
      return response.status(200).json({ success: false, msg: message.msg_empty_param, key: 'banner_id' });
    }
    var sqlDelete = "DELETE FROM banner_master WHERE delete_flag = 0 AND banner_id = ?";
    connection.query(sqlDelete, [banner_id], async (error, deleteResult) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      if (deleteResult.affectedRows > 0) {
        return response.status(200).json({ success: true, msg: message.bannerDeletedSuccesfully })
      } else {
        return response.status(200).json({ success: false, msg: message.bannerDeletedUnSuccesfully })
      }
    })
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
}
const editBanner = async (request, response) => {
  const { banner_id } = request.body;
  try {
    if (!banner_id) {
      return response.status(200).json({ success: false, msg: message.msg_empty_param, key: 'banner_id' });
    }
    var image = request.files?.image;
    var getBannerQuery = "SELECT image FROM banner_master WHERE banner_id = ? AND delete_flag = 0";
    connection.query(getBannerQuery, [banner_id], (err, results) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: err.message });
      }
      if (results.length === 0) {
        return response.status(200).json({ success: false, msg: message.bannerNotFound });
      }
      let existingImage = results[0].image;
      var image_video = (image ? image[0].filename : existingImage);
      var sqlUpdate = `UPDATE banner_master SET image = ?,updatetime = now() WHERE banner_id = ? AND delete_flag = 0`;

      connection.query(sqlUpdate, [image_video, banner_id], async (error, result) => {
        if (error) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }

        if (result.affectedRows > 0) {
          return response.status(200).json({ success: true, msg: message.bannerEditSuccessfully });
        } else {
          return response.status(200).json({ success: false, msg: message.bannerEditUnSuccessfully });
        }
      });
    });

  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

// Service APIs
const getServiceType = async (request, response) => {
  try {
    var sqlSelect = "SELECT service_type_id, service_type, delete_flag, createtime, updatetime FROM service_type_master WHERE delete_flag = 0 ORDER BY service_type_id DESC";
    connection.query(sqlSelect, async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      var service_arr = [];
      if (result.length === 0) {
        return response.status(200).json({ success: true, msg: message.msgDataFound, service_arr: [] });
      }
      if (result.length > 0) {
        for (var data of result) {
          service_arr.push({
            service_type_id: data.service_type_id,
            service_type: data.service_type,
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
            updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, service_arr: service_arr });
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, service_arr: [] });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const addServiceType = async (request, response) => {
  const { service_type } = request.body;

  if (!service_type) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_type' });
  }

  try {
    const sqlCheck = "SELECT * FROM service_type_master WHERE LOWER(service_type) = LOWER(?) AND delete_flag = 0";
    connection.query(sqlCheck, [service_type], async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: "service_type" });
      } else {
        const insertQuery = `INSERT INTO service_type_master (service_type, createtime, updatetime) VALUES (?, NOW(), NOW())`;
        const values = [service_type];

        connection.query(insertQuery, values, (error, result) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
          }

          if (result.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: "Service added successfully" });
          } else {
            return response.status(200).json({ success: false, msg: "Failed to add service" });
          }
        });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const deleteServiceType = async (request, response) => {
  const { service_type_id } = request.body;

  if (!service_type_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_type_id' });
  }

  try {
    const sqlCheck = "SELECT * FROM service_type_master WHERE service_type_id = ? AND delete_flag = 0";
    connection.query(sqlCheck, [service_type_id], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.noDataFound });
      }
      const deleteQuery = `UPDATE service_type_master SET delete_flag = 1, updatetime = NOW() WHERE service_type_id = ?`;
      connection.query(deleteQuery, [service_type_id], (error, deleteResult) => {
        if (error) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        return response.status(200).json({ success: true, msg: "Service deleted successfully" });
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const editServiceType = async (request, response) => {
  const { service_type_id, service_type } = request.body;

  if (!service_type_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_type_id' });
  }

  if (!service_type) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_type' });
  }

  try {
    // Check if service exists
    const sqlCheck = "SELECT * FROM service_type_master WHERE service_type_id = ? AND delete_flag = 0";
    connection.query(sqlCheck, [service_type_id], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.noDataFound });
      }

      // Check for duplicate service type (excluding current service)
      const duplicateCheck = "SELECT * FROM service_type_master WHERE LOWER(service_type) = LOWER(?) AND service_type_id != ? AND delete_flag = 0";
      connection.query(duplicateCheck, [service_type, service_type_id], (duplicateError, duplicateResult) => {
        if (duplicateError) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: duplicateError.message });
        }

        if (duplicateResult.length > 0) {
          return response.status(200).json({ success: false, msg: message.msgDataFound, key: "service_type" });
        }

        // Update service
        const updateQuery = `UPDATE service_type_master SET service_type = ?, updatetime = NOW() WHERE service_type_id = ? AND delete_flag = 0`;
        const values = [service_type, service_type_id];

        connection.query(updateQuery, values, (updateError, updateResult) => {
          if (updateError) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: updateError.message });
          }

          if (updateResult.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: "Service updated successfully" });
          } else {
            return response.status(200).json({ success: false, msg: "Failed to update service" });
          }
        });
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

// Service APIs for service_master table
const getService = async (request, response) => {
  try {
    var sqlSelect = "SELECT service_id, service_type_id,service_name, description, image, price, createtime, updatetime FROM service_master WHERE delete_flag = 0 ORDER BY service_id DESC";
    connection.query(sqlSelect, async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      var service_arr = [];
      if (result.length === 0) {
        return response.status(200).json({ success: true, msg: message.msgDataFound, service_arr: [] });
      }
      if (result.length > 0) {
        for (var data of result) {
          service_arr.push({
            service_id: data.service_id,
            service_name: data.service_name,
            description: data.description || "NA",
            image: data.image,
            service_type_id: data.service_type_id,
            price: data.price,
            service_type: await getServiceTypeData(data.service_type_id),
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
            updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, service_arr: service_arr });
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, service_arr: [] });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const addService = async (request, response) => {
  const { service_name, description, price, service_type_id } = request.body;

  if (!service_name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_name' });
  }

  if (!service_type_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_type_id' });
  }

  if (!price) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'price' });
  }

  let image = request.file ? request.file.filename : null;

  if (!image) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'image' });
  }

  try {
    const sqlCheck = "SELECT * FROM service_master WHERE LOWER(service_name) = LOWER(?) AND delete_flag = 0";
    connection.query(sqlCheck, [service_name], async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: "service_name" });
      } else {
        const insertQuery = `INSERT INTO service_master (service_type_id,service_name, description, image, price, createtime, updatetime) VALUES (?,?, ?, ?, ?, NOW(), NOW())`;
        const values = [service_type_id, service_name, description || null, image, price];

        connection.query(insertQuery, values, (error, result) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
          }

          if (result.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: "Service added successfully" });
          } else {
            return response.status(200).json({ success: false, msg: "Failed to add service" });
          }
        });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const deleteService = async (request, response) => {
  const { service_id } = request.body;

  if (!service_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_id' });
  }

  try {
    const sqlCheck = "SELECT * FROM service_master WHERE service_id = ? AND delete_flag = 0";
    connection.query(sqlCheck, [service_id], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.noDataFound });
      }
      const deleteQuery = `UPDATE service_master SET delete_flag = 1, updatetime = NOW() WHERE service_id = ?`;
      connection.query(deleteQuery, [service_id], (error, deleteResult) => {
        if (error) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
        }
        return response.status(200).json({ success: true, msg: "Service deleted successfully" });
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const editService = async (request, response) => {
  const { service_id, service_name, description, price } = request.body;

  if (!service_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_id' });
  }

  if (!service_name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_name' });
  }

  if (!price) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'price' });
  }

  let image = request.file ? request.file.filename : null;

  try {
    // Check if service exists
    const sqlCheck = "SELECT * FROM service_master WHERE service_id = ? AND delete_flag = 0";
    connection.query(sqlCheck, [service_id], (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.noDataFound });
      }

      // Check for duplicate service name (excluding current service)
      const duplicateCheck = "SELECT * FROM service_master WHERE LOWER(service_name) = LOWER(?) AND service_id != ? AND delete_flag = 0";
      connection.query(duplicateCheck, [service_name, service_id], (duplicateError, duplicateResult) => {
        if (duplicateError) {
          return response.status(200).json({ success: false, msg: message.internalServerError, error: duplicateError.message });
        }

        if (duplicateResult.length > 0) {
          return response.status(200).json({ success: false, msg: message.msgDataFound, key: "service_name" });
        }

        // Update service
        let updateQuery, values;
        if (image) {
          updateQuery = `UPDATE service_master SET service_name = ?, description = ?, price = ?, image = ?, updatetime = NOW() WHERE service_id = ? AND delete_flag = 0`;
          values = [service_name, description || null, price, image, service_id];
        } else {
          updateQuery = `UPDATE service_master SET service_name = ?, description = ?, price = ?, updatetime = NOW() WHERE service_id = ? AND delete_flag = 0`;
          values = [service_name, description || null, price, service_id];
        }

        connection.query(updateQuery, values, (updateError, updateResult) => {
          if (updateError) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: updateError.message });
          }

          if (updateResult.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: "Service updated successfully" });
          } else {
            return response.status(200).json({ success: false, msg: "Failed to update service" });
          }
        });
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const getServiceDetail = async (request, response) => {
  const { service_id } = request.query;

  try {
    if (!service_id) {
      return response.status(200).json({ success: false, msg: message.empt_params, key: 'service_id' });
    }

    var sqlSelect = "SELECT service_id, service_type_id, service_name, description, image, price, createtime, updatetime FROM service_master WHERE service_id = ? AND delete_flag = 0";
    connection.query(sqlSelect, [service_id], async (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: err.message });
      }

      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.noDataFound });
      }

      const data = result[0];
      const serviceDetail = {
        service_id: data.service_id,
        service_name: data.service_name,
        description: data.description || "NA",
        image: data.image,
        price: data.price,
        service_type_id: data.service_type_id,
        service_type: await getServiceTypeData(data.service_type_id),
        createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
        updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
      };

      return response.status(200).json({
        success: true,
        msg: message.msgDataFound,
        service_detail: serviceDetail
      });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const getBooking = async (request, response) => {
  try {
    var sqlSelect = `SELECT b.booking_id,b.user_id,b.vendor_id,b.service_id,b.amount,b.status,b.service_name,b.delete_flag,b.createtime,b.updatetime,u.name as user_name,u.mobile as user_mobile,u.email as user_email FROM booking_master b LEFT JOIN user_master u ON b.user_id = u.user_id WHERE b.delete_flag = 0  ORDER BY b.booking_id DESC`;

    connection.query(sqlSelect, async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      var booking_arr = [];
      if (result.length === 0) {
        return response.status(200).json({ success: true, msg: message.msgDataFound, booking_arr: [] });
      }

      if (result.length > 0) {
        for (var data of result) {
          let status_label = data.status == 0 ? "Pending" : data.status == 1 ? "Ongoing" : data.status == 2 ? "Completed" : "Unknown";
          booking_arr.push({
            booking_id: data.booking_id,
            user_id: data.user_id,
            vendor_id: data.vendor_id,
            service_id: data.service_id,
            amount: data.amount,
            status: data.status,
            status_label: status_label,
            service_name: data.service_name,
            user_name: data.user_name || "NA",
            user_mobile: data.user_mobile || "NA",
            user_email: data.user_email || "NA",
            createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
            updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, booking_arr: booking_arr });
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, booking_arr: [] });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const getVendorName = async (request, response) => {
  try {
    const sqlCheckUser =
      "SELECT user_id, name FROM user_master WHERE delete_flag = 0 AND profile_complete = 1 AND otp_verify = 1 AND user_type = 2 ORDER BY user_id DESC";

    connection.query(sqlCheckUser, async (err, userResult) => {
      if (err) {
        return response.status(200).json({
          success: false,
          msg: message.internalServerError,
          err: err.message,
        });
      }

      var user_arr = [];
      if (userResult.length <= 0) {
        return response.status(200).json({
          success: true,
          msg: message.msgDataFound,
          user_arr: user_arr,
        });
      }
      if (userResult.length > 0) {
        for (var data of userResult) {
          user_arr.push({
            // s_no: s_no,
            user_id: data.user_id,
            name: data.name,
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, user_arr: user_arr.length > 0 ? user_arr : "NA" });
      }
    });
  } catch (error) {
    return response.status(200).json({
      success: false,
      msg: message.internalServerError,
      err: error.message,
    });
  }
}

const addAMCPlan = async (request, response) => {
  const { plan_name, amount, duration, description } = request.body;

  if (!plan_name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'plan_name' });
  }
  if (!amount) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'amount' });
  }
  if (!duration) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'duration' });
  }
  if (!description) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'description' });
  }

  try {
    // Check for duplicate plan name
    const sqlCheck = "SELECT * FROM subscription_master WHERE LOWER(plan_name) = LOWER(?) AND delete_flag = 0";
    connection.query(sqlCheck, [plan_name], async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }

      if (result.length > 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, key: "plan_name" });
      } else {
        const insertQuery = `INSERT INTO subscription_master (no_of_day, plan_name, plan_description, createtime, updatetime) VALUES (?, ?, ?, NOW(), NOW())`;
        const values = [duration, plan_name, description];

        connection.query(insertQuery, values, (error, result) => {
          if (error) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
          }

          if (result.affectedRows > 0) {
            return response.status(200).json({ success: true, msg: ["AMC Plan added successfully"] });
          } else {
            return response.status(200).json({ success: false, msg: ["Failed to add AMC Plan"] });
          }
        });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const getAms = async (request, response) => {
  try {
    var sqlSelect = "SELECT subscription_id, no_of_day, plan_name, plan_description, createtime, updatetime, amount FROM subscription_master WHERE delete_flag = 0 ORDER BY subscription_id DESC";
    connection.query(sqlSelect, async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      var amc_arr = [];
      if (result.length > 0) {
        for (var data of result) {
          amc_arr.push({
            subscription_id: data.subscription_id,
            month: data.no_of_day,
            plan_name: data.plan_name,
            plan_description: data.plan_description,
            amount: data.amount || 0.0,
            createtime: data.createtime ? moment(data.createtime).format("DD-MM-YYYY HH:mm A") : "NA",
            updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
          });
        }
        return response.status(200).json({ success: true, msg: message.msgDataFound, amc_arr: amc_arr.length > 0 ? amc_arr : [] });
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, amc_arr: "NA" });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const getAmsDetail = async (request, response) => {
  const { subscription_id } = request.query;
  if (!subscription_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'subscription_id' });
  }
  try {
    var sqlSelect = "SELECT subscription_id, no_of_day, plan_name, plan_description, createtime, updatetime, amount FROM subscription_master WHERE delete_flag = 0 AND subscription_id = ?";
    connection.query(sqlSelect, [subscription_id], async (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      if (result.length > 0) {
        const data = result[0];
        const amc_detail = {
          subscription_id: data.subscription_id,
          month: data.no_of_day,
          plan_name: data.plan_name,
          description: data.plan_description,
          amount: data.amount || 0.0,
          createtime: data.createtime ? moment(data.createtime).format("DD-MM-YYYY HH:mm A") : "NA",
          updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : "NA"
        };
        return response.status(200).json({ success: true, msg: message.msgDataFound, amc_detail });
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, amc_detail: {} });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const editAms = async (request, response) => {
  const { subscription_id, plan_name, amount, duration, description } = request.body;
  if (!subscription_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'subscription_id' });
  }
  if (!plan_name) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'plan_name' });
  }
  if (!amount) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'amount' });
  }
  if (!duration) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'duration' });
  }
  if (!description) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'description' });
  }
  const updateQuery = `UPDATE subscription_master SET no_of_day = ?, plan_name = ?, plan_description = ?,  updatetime = NOW(), amount = ? WHERE subscription_id = ? AND delete_flag = 0`;
  var values = [duration, plan_name, description, amount, subscription_id]
  try {
    connection.query(updateQuery, values, (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      if (result.affectedRows > 0) {
        return response.status(200).json({ success: true, msg: message.DetailsUpdated });
      } else {
        return response.status(200).json({ success: false, msg: message.errorUpdating });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};

const assignVendor = async (request, response) => {
  const { booking_id, vendor_id } = request.body;
  if (!booking_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'booking_id' });
  }
  if (!vendor_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'vendor_id' });
  }
  const updateQuery = `UPDATE booking_master SET vendor_id = ? WHERE Booking_id = ? AND delete_flag = 0`;
  var values = [vendor_id, booking_id]
  try {
    connection.query(updateQuery, values, (error, result) => {
      if (error) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
      }
      if (result.affectedRows > 0) {
        return response.status(200).json({ success: true, msg: message.DetailsUpdated });
      } else {
        return response.status(200).json({ success: false, msg: message.errorUpdating });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
}

const getBookingDetail = async (request, response) => {
  const { booking_id } = request.query;
  if (!booking_id) {
    return response.status(200).json({ success: false, msg: message.empt_params, key: 'booking_id' });
  }
  try {
    const sql = `SELECT b.*, 
      u.name as user_name, u.email as user_email, u.mobile as user_mobile,
      v.name as vendor_name, v.email as vendor_email, v.mobile as vendor_mobile
      FROM booking_master b
      LEFT JOIN user_master u ON b.user_id = u.user_id
      LEFT JOIN user_master v ON b.vendor_id = v.user_id
      WHERE b.booking_id = ? AND b.delete_flag = 0`;
    connection.query(sql, [booking_id], (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: err.message });
      }
      if (result.length > 0) {
        const data = result[0];
        const booking_detail = {
          booking_id: data.booking_id,
          user_id: data.user_id,
          vendor_id: data.vendor_id,
          service_id: data.service_id,
          case_id  : data.case_id,
          amount: data.amount,
          status: data.status,
          service_name: data.service_name,
          user_name: data.user_name || 'NA',
          user_email: data.user_email || 'NA',
          user_mobile: data.user_mobile || 'NA',
          vendor_name: data.vendor_name || 'NA',
          vendor_email: data.vendor_email || 'NA',
          vendor_mobile: data.vendor_mobile || 'NA',
          appointment_date : (data.appointment_date != null) ? moment(data.appointment_date).format("DD-MM-YYYY") : "NA",
          createtime: data.createtime ? moment(data.createtime).format("DD-MM-YYYY HH:mm A") : 'NA',
          updatetime: data.updatetime ? moment(data.updatetime).format("DD-MM-YYYY HH:mm A") : 'NA'
        };
        return response.status(200).json({ success: true, msg: message.msgDataFound, booking_detail });
      } else {
        return response.status(200).json({ success: true, msg: message.msgDataFound, booking_detail: {} });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError, error: error.message });
  }
};
const getTicketData = async (request, response) => {
  try {
    var sqlSelect =
      "SELECT cm.ticket_id, cm.user_id, cm.name,um.username,cm.email, cm.issue, cm.status, cm.title, cm.reply, cm.reply_datetime, cm.createtime, cm.mobile FROM ticket_master as cm JOIN user_master as um on cm.user_id = um.user_id WHERE cm.delete_flag = 0 AND um.delete_flag = 0 order by cm.ticket_id desc";
    connection.query(sqlSelect, async (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error : err.message });
      }
      var contact_arr = [];
      if (result.length === 0) {
        return response.status(200).json({ success: false, msg: message.msgDataFound, contact_arr: contact_arr });
      }
      var s_no = 0;
      for (var data of result) {
        s_no++;
        contact_arr.push({
          s_no: s_no,
          ticket_id: data.ticket_id,
          username: data.name,
          name: data.name,
          email: data.email,
          issue: data.issue,
          status: data.status,
          status_lable: (data.status == 0) ? "pending" : "replied",
          title: data.title,
          reply_datetime: data.reply_datetime ? moment(data.reply_datetime).format("DD-MM-YYYY HH:mm A") : "NA",
          reply: data.reply,
          createtime: moment(data.createtime).format("DD-MM-YYYY HH:mm A"),
        });
      }
      return response.status(200).json({ success: true, msg: message.msgDataFound, contact_arr: contact_arr });
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError });
  }
};


const updateStatus = async (request, response) => {
  const { ticket_id, message } = request.body;
  if (!ticket_id || !message) {
    return response.status(200).json({ success: false, msg: message.msg_empty_param });
  }
  try {
    var check = "SELECT ticket_id, status FROM ticket_master WHERE ticket_id = ? AND delete_flag = 0";
    connection.query(check, [ticket_id], async (err, res) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, error: err, });
      }
      if (res.length <= 0) {
        return response.status(200).json({ success: false, msg: message.msgDataNotFound });
      }
      if (res.length > 0) {
        var update = "UPDATE ticket_master SET status = 1 ,reply = ? , reply_datetime = NOW() WHERE ticket_id =?";
        connection.query(update, [message, ticket_id], async (err) => {
          if (err) {
            return response.status(200).json({ success: false, msg: message.internalServerError, error: err });
          } else {
            return response.status(200).json({ success: true, msg: message.repliedSuccessfully, msg: message });
          }
        });
      } else {
        return response.status(200).json({ success: false, msg: message.msgDataNotFound });
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, msg: message.internalServerError });
  }
};
const SendMail = async (req, response) => {
  try {
    const { user_email, user_name, message, title } = req.body;
    if (!user_email || !user_name || !message || !title) {
      return response.status(200).json({ success: false, msg: "req", error: req.body });
    }
    const fetchAdmin = "SELECT username, email FROM user_master WHERE user_type IN (0,3) AND delete_flag = 0";
    connection.query(fetchAdmin, async (err, result) => {
      if (err) {
        return response.status(200).json({ success: false, msg: message.internalServerError, err: err.message, });
      }
      if (result.length <= 0) {
        return response.status(404).json({ success: false, msg: message.msgDataNotFound });
      }
      if (result.length > 0) {
        var adminName = result[0].username;
        const adminEmail = result[0].email;
        const subject = "Ticket Resolved Reply";
        const newMsg = message;
        const app_name = 'FixFly';
        const app_logo = 'http://localhost:3001/logo/logo.jpg';
        var mailBody = mailBodyContactUs({ adminName, adminEmail, user_email, title, subject, user_name, newMsg, app_logo, app_name });
        try {
          const mailResponse = await sendMail(user_email, subject, mailBody);
          if (mailResponse.success) {
            return response.status(200).json({ success: true, msg: message.EmailSent });
          } else {
            return response.status(200).json({ success: false, msg: "error1", error: mailResponse.error });
          }
        } catch (error) {
          return response.status(200).json({ success: false, msg: "error1", error: error.message });
        }
      }
    });
  } catch (error) {
    return response.status(200).json({ success: false, error: error.message, msg: "err2" });
  }
};


module.exports = { signIn, getFaq, getCategory, getSubCategory, createUserProfile, createTicket, getSubscription, purchasePlan, adminLoginController, getAdminAllData, UpdateAdminProfile, UpdateAdminPassword, addCategory, deleteCategory, editCategory, addSubCategory, deleteSubCategory, editSubCategory, getAllFaq, getAllFaqById, addFAQ, deleteFaq, editFaq, CheckAdminEmail, AdminForgetPassword, getAllUserDataController, ViewUserDetails, getTotalUserCount, getAllDeletedUser, updateContent, fetchaboutcontent, getProduct, getProductDetail, addProduct, deleteProduct, editProduct, getAllVendorDataController, getAllDeletedVendorDataController, ActivateDeactivateUser, getBanner, addBanner, deleteBanner, editBanner, getSelectedSubCategory, getServiceType, addServiceType, deleteServiceType, editServiceType, getService, getServiceDetail, addService, deleteService, editService, getBooking, getVendorName, addAMCPlan, getAms, getAmsDetail, editAms, assignVendor, getBookingDetail ,getTicketData, SendMail, updateStatus}