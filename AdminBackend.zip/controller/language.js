var message = {
    empt_params : ["Please Send Data"],
    internalServerError : ["Internal Server Error"],
    msgDataFound : ["Data Found Successfully"],
    userNotFound : ["User Not Found"],
    userAccountDeactivate : ["User Account Deactivated by Admin"],
    dataUpdated : ["profile  Created Successfully"],
    ticketAdded : ["Ticket Added Successfully"],

    emailNotRegistered : ["Email Not Found"],
    loginSuccessfully : ["Login Successfully"],
    categoryEditSuccess : ["Category Updated Successfully"],
    categoryEditUnSuccess : ["Category Updated UnSuccessfully"],
    DetailsUpdated : ["FAQ deleted successfully"],
    msgDataNotFound : ["Data Not Found"],
}

module.exports = message;