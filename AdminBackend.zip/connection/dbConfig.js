var mysql = require("mysql");
var connection = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
    database : "fixfly_db",
});
connection.connect((err) => {
    if(err) {
        console.log("error in connection");
    }
    console.log("database connect successfully");
});

module.exports = connection;